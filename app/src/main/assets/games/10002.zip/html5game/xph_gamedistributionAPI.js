/**
	 * Example
	 */

   var initialized = false; 
   
   function initGDApi()
   { // invoke this function to initialize api
	   
	if(!initialized){ // Api will be initialized once, so preroll is shown once either
	   
		   var settings = {
            gameId: "2c3a4762932e474ebf78124c4de3fbf0",
            userId: "ABD36C6C-E74B-4BA7-BE87-0AB01F98D30D-s1",
            resumeGame: resumeGame,
            pauseGame: pauseGame,
            onInit: function (data) {
			   initialized = true;
            },
            onError: function (data) {
               console.log("Error:"+data);
            }
			};
		
       
			// gdApi(settings);

			function resumeGame() {
				console.log("Resume game");
			}

			function pauseGame() {
				console.log("Pause game");
			}  

	   }
	   
   }

function gdApi_init()
{ 	
   initGDApi(); // in order to initialize api
}

   /**
 * Shows banner, you can use it between levels
 */	

function gdApi_showBanner()
{ 	
	if (initialized)
		gdApi.showBanner(); 
}		

/**
 * GD Logger sends how many times 'PlayGame' is called. If you invoke 'PlayGame' many times, it increases 
 * 'PlayGame' counter and sends this counter value. 
 */		
function gdApi_play()
{ 	
	if (initialized)
		gdApi.play();
}

/**
 * GD Logger sends how many times 'CustomLog' that is called related to given by _key name. If you invoke 
 * 'CustomLog' many times, it increases 'CustomLog' counter and sends this counter value. 
 * @param	key		Your custom key it should be maximum 10 chars
 */		
function gdApi_customLog(_Key)
{ 	
	if (initialized)
		gdApi.customLog(_Key);
}