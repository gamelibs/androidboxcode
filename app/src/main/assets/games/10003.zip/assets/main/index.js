window.__require = function t(e, o, n) {
    function i(s, c) {
        if (!o[s]) {
            if (!e[s]) {
                var a = s.split("/");
                if (a = a[a.length - 1],
                    !e[a]) {
                    var u = "function" == typeof __require && __require;
                    if (!c && u)
                        return u(a, !0);
                    if (r)
                        return r(a, !0);
                    throw new Error("Cannot find module '" + s + "'")
                }
                s = a
            }
            var l = o[s] = {
                exports: {}
            };
            e[s][0].call(l.exports, function (t) {
                return i(e[s][1][t] || t)
            }, l, l.exports, t, e, o, n)
        }
        return o[s].exports
    }
    for (var r = "function" == typeof __require && __require, s = 0; s < n.length; s++)
        i(n[s]);
    return i
}({
    AudioPlayer: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "6ded9VqaA5MjZErune4OGJZ", "AudioPlayer");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        );
        Object.defineProperty(o, "__esModule", {
            value: !0
        }),
            o.AUDIO_CONFIG = o.AudioPlayer = void 0;
        var r, s = t("../loader/loader_mgr"), c = t("../util"), a = t("../base/SingletonClass"), u = t("../localStorage/LocalStorage"), l = function (t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.clip_cache = new Map,
                    e.loading_map = new Map,
                    e.music_id = -1,
                    e.sound_ids = [],
                    e
            }
            return i(e, t),
                e.ins = function () {
                    return t.ins.call(this)
                }
                ,
                e.prototype.init = function () {
                    this.set_music_mute(u.LocalStorage.ins().getLocal(u.CONST_STORAGE_KEY.KEY_MUSIC_IS_MUTE, !1)),
                        this.set_music_volume(u.LocalStorage.ins().getLocal(u.CONST_STORAGE_KEY.KEY_MUSIC_VOLUME, .5)),
                        this.set_sound_mute(u.LocalStorage.ins().getLocal(u.CONST_STORAGE_KEY.KEY_SOUND_IS_MUTE, !1)),
                        this.set_sound_volume(u.LocalStorage.ins().getLocal(u.CONST_STORAGE_KEY.KEY_SOUND_VOLUME, 1))
                }
                ,
                e.prototype.flush = function () { }
                ,
                e.prototype.play_music = function (t) {
                    this.music_id >= 0 && this.stop_music();
                    var e = c.strfmt("sound/{0}", t);
                    if (this.curr_music = t,
                        !this.music_mute) {
                        var o = this.clip_cache.get(e);
                        if (o)
                            this.play_clip(o, this.music_volume, !0, r.Music);
                        else {
                            var n = {
                                type: r.Music,
                                name: t,
                                path: e,
                                volume: this.music_volume,
                                loop: !0
                            };
                            this.load_task(n)
                        }
                    }
                }
                ,
                e.prototype.stop_music = function () {
                    this.music_id < 0 || (cc.audioEngine.stop(this.music_id),
                        this.music_id = -1)
                }
                ,
                e.prototype.get_music_mute = function () {
                    return this.music_mute
                }
                ,
                e.prototype.set_music_mute = function (t) {
                    this.music_mute = t,
                        u.LocalStorage.ins().setLocal(u.CONST_STORAGE_KEY.KEY_MUSIC_IS_MUTE, t),
                        this.music_id < 0 ? !t && this.curr_music && this.play_music(this.curr_music) : t ? cc.audioEngine.pause(this.music_id) : cc.audioEngine.resume(this.music_id)
                }
                ,
                e.prototype.set_music_volume = function (t) {
                    this.music_volume = t,
                        this.music_id >= 0 && cc.audioEngine.setVolume(this.music_id, t),
                        u.LocalStorage.ins().setLocal(u.CONST_STORAGE_KEY.KEY_MUSIC_VOLUME, t)
                }
                ,
                e.prototype.load_task = function (t) {
                    var e = t.path;
                    this.loading_map.get(e) || (this.loading_map.set(e, !0),
                        s.loader_mgr.get_inst().loadRawAsset(e, c.gen_handler(this.on_clip_loaded, this, t)))
                }
                ,
                e.prototype.on_clip_loaded = function (t, e) {
                    this.clip_cache.set(t.path, e),
                        t.type == r.Music && t.name != this.curr_music || this.play_clip(e, t.volume, t.loop, t.type, t.cb)
                }
                ,
                e.prototype.play_clip = function (t, e, o, n, i) {
                    var s = this
                        , c = cc.audioEngine.play(t, o, e);
                    n == r.Music ? this.music_id = c : n == r.Sound && (this.sound_ids.push(c),
                        cc.audioEngine.setFinishCallback(c, function () {
                            s.on_sound_finished(c),
                                i && i.exec()
                        }))
                }
                ,
                e.prototype.on_sound_finished = function (t) {
                    var e = this.sound_ids.findIndex(function (e) {
                        return e == t
                    });
                    -1 != e && this.sound_ids.splice(e, 1)
                }
                ,
                e.prototype.play_sound = function (t, e) {
                    if (!this.sound_mute) {
                        var o = c.strfmt("sound/{0}", t)
                            , n = this.clip_cache.get(o);
                        if (n)
                            this.play_clip(n, this.sound_volume, !1, r.Sound, e);
                        else {
                            var i = {
                                type: r.Sound,
                                name: t,
                                path: o,
                                volume: this.sound_volume,
                                loop: !1,
                                cb: e
                            };
                            this.load_task(i)
                        }
                    }
                }
                ,
                e.prototype.get_sound_mute = function () {
                    return this.sound_mute
                }
                ,
                e.prototype.set_sound_mute = function (t) {
                    this.sound_mute = t,
                        this.sound_ids.forEach(function (e) {
                            t ? cc.audioEngine.pause(e) : cc.audioEngine.resume(e)
                        }),
                        u.LocalStorage.ins().setLocal(u.CONST_STORAGE_KEY.KEY_SOUND_IS_MUTE, t)
                }
                ,
                e.prototype.set_sound_volume = function (t) {
                    this.sound_volume = t,
                        this.sound_ids.forEach(function (e) {
                            cc.audioEngine.setVolume(e, t)
                        }),
                        u.LocalStorage.ins().setLocal(u.CONST_STORAGE_KEY.KEY_SOUND_VOLUME, t)
                }
                ,
                e.prototype.pause_by_game = function () {
                    var t = this;
                    this._pausedByGame = !0;
                    try {
                        this.music_id >= 0 && cc.audioEngine.pause(this.music_id)
                    } catch (t) { }
                    try {
                        this.sound_ids.forEach(function (e) {
                            try {
                                cc.audioEngine.pause(e)
                            } catch (t) { }
                        })
                    } catch (t) { }
                }
                ,
                e.prototype.resume_by_game = function () {
                    var t = this;
                    if (this._pausedByGame) {
                        this._pausedByGame = !1;
                        try {
                            !this.music_mute && this.music_id >= 0 && cc.audioEngine.resume(this.music_id)
                        } catch (t) { }
                        try {
                            this.sound_mute || this.sound_ids.forEach(function (e) {
                                try {
                                    cc.audioEngine.resume(e)
                                } catch (t) { }
                            })
                        } catch (t) { }
                    }
                }
                ,
                e.prototype.stop_sound = function () {
                    this.sound_ids.forEach(function (t) {
                        cc.audioEngine.stop(t)
                    }),
                        this.sound_ids.length = 0
                }
                ,
                e.prototype.clear_cache = function () {
                    this.clip_cache.forEach(function (t) {
                        s.loader_mgr.get_inst().release(t)
                    }),
                        this.clip_cache.clear(),
                        this.loading_map.clear(),
                        cc.audioEngine.uncacheAll()
                }
                ,
                e
        }(a.default);
        o.AudioPlayer = l,
            function (t) {
                t[t.Music = 1] = "Music",
                    t[t.Sound = 2] = "Sound"
            }(r || (r = {})),
            o.AUDIO_CONFIG = {
                Audio_Btn: "Firing Balls_ButtonClick",
                Audio_freeze: "Firing Balls_GamePlay_PowerUp_TileFreeze",
                Audio_speed: "Firing Balls_gamePlay_PowerUp_SuperSpeed",
                Audio_mega: "Firing balls_GamePlay_PowerUP_MegaCannon",
                Audio_balls: "Firing Balls_GamePlay_BallAdd1",
                Audio_Bgm: "Firing Balls_ BG_Music",
                Audio_gameover: "Firing Balls_GamePlay_LifeLost",
                Audio_win: "Firing Balls_ Game Over_Score",
                Audio_congra: "Firing Balls_GameOver_HighScore"
            },
            cc._RF.pop()
    }
        , {
        "../base/SingletonClass": "SingletonClass",
        "../loader/loader_mgr": "loader_mgr",
        "../localStorage/LocalStorage": "LocalStorage",
        "../util": "util"
    }],
    BallItem: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "908e7hGo41Op5knNUQ8AuMr", "BallItem");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        ), r = this && this.__decorate || function (t, e, o, n) {
            var i, r = arguments.length, s = r < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                s = Reflect.decorate(t, e, o, n);
            else
                for (var c = t.length - 1; c >= 0; c--)
                    (i = t[c]) && (s = (r < 3 ? i(s) : r > 3 ? i(e, o, s) : i(e, o)) || s);
            return r > 3 && s && Object.defineProperty(e, o, s),
                s
        }
            ;
        Object.defineProperty(o, "__esModule", {
            value: !0
        }),
            o.EnumBallStatus = void 0;
        var s, c = t("../GameConst"), a = t("../model/GameModel"), u = t("../../common/util"), l = cc._decorator, _ = l.ccclass, p = l.property, h = function (t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.ball_type = 0,
                    e.ball_icon = null,
                    e._ball_status = 0,
                    e._power_scale = 1,
                    e
            }
            return i(e, t),
                Object.defineProperty(e.prototype, "ball_status", {
                    get: function () {
                        return this._ball_status
                    },
                    set: function (t) {
                        var e = this;
                        switch (this._ball_status = t,
                        t) {
                            case s.onLand:
                                this.scheduleOnce(function () {
                                    e.node && e.node.active && (e.node.setPosition(c.default.ins().ball_init_x, c.default.ins().ball_init_y),
                                        e.ball_status = s.onReady)
                                }, 0);
                                break;
                            case s.onReady:
                            case s.onRemoved:
                        }
                    },
                    enumerable: !1,
                    configurable: !0
                }),
                Object.defineProperty(e.prototype, "power_scale", {
                    get: function () {
                        return this._power_scale
                    },
                    set: function (t) {
                        this._power_scale = t,
                            this.ball_icon.node.setScale(t > 1 ? 1.5 : 1)
                    },
                    enumerable: !1,
                    configurable: !0
                }),
                e.prototype.reset = function () {
                    this.node.stopAllActions(),
                        this._ball_status = s.onRemoved,
                        this.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 0),
                        this.power_scale = 1,
                        this.node.active = !1
                }
                ,
                e.prototype.init = function (t, e, o) {
                    this.power_scale = 1,
                        this.node.x = t,
                        this.node.y = e,
                        this.ball_status = o,
                        u.load_plist_img(this.ball_icon, "texture/plist/customize", "ball0")
                }
                ,
                e.prototype.fireBall = function (t) {
                    var e = t * Math.PI / 180
                        , o = c.default.ins().ball_speed + 400 * a.default.ins().ball_fire_speed;
                    this.getComponent(cc.RigidBody).linearVelocity = cc.v2(Math.sin(e) * o, Math.cos(e) * o),
                        this.ball_status = s.onFire
                }
                ,
                e.prototype.onBeginContact = function (t, e, o) {
                    switch (o.tag) {
                        case 1:
                            this.node.active && (this.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 0),
                                this.ball_status = s.onLand)
                    }
                }
                ,
                r([p(cc.Integer)], e.prototype, "ball_type", void 0),
                r([p(cc.Sprite)], e.prototype, "ball_icon", void 0),
                r([_], e)
        }(cc.Component);
        o.default = h,
            function (t) {
                t[t.onReady = 0] = "onReady",
                    t[t.onLand = 1] = "onLand",
                    t[t.onFire = 2] = "onFire",
                    t[t.onRemoved = 3] = "onRemoved"
            }(s = o.EnumBallStatus || (o.EnumBallStatus = {})),
            cc._RF.pop()
    }
        , {
        "../../common/util": "util",
        "../GameConst": "GameConst",
        "../model/GameModel": "GameModel"
    }],
    BrickItem: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "8395bFNuq1NjrVnqs7rG2hF", "BrickItem");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        ), r = this && this.__decorate || function (t, e, o, n) {
            var i, r = arguments.length, s = r < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                s = Reflect.decorate(t, e, o, n);
            else
                for (var c = t.length - 1; c >= 0; c--)
                    (i = t[c]) && (s = (r < 3 ? i(s) : r > 3 ? i(e, o, s) : i(e, o)) || s);
            return r > 3 && s && Object.defineProperty(e, o, s),
                s
        }
            ;
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var s = t("../model/GameModel")
            , c = t("../../common/event/EventDispatch")
            , a = t("../GameConst")
            , u = t("./BallItem")
            , l = t("../../common/audio/AudioPlayer")
            , _ = cc._decorator
            , p = _.ccclass
            , h = _.property
            , d = function (t) {
                function e() {
                    var e = null !== t && t.apply(this, arguments) || this;
                    return e.lb_hp = null,
                        e.icon = null,
                        e.icon_hp_reduce = null,
                        e.icon_power = null,
                        e.brick_type = 0,
                        e.star_num = 0,
                        e.ball_num = 0,
                        e.effect_type = 0,
                        e.brick_radius_mul = 1,
                        e._hp = 1,
                        e._color_hp = 1,
                        e
                }
                return i(e, t),
                    Object.defineProperty(e.prototype, "hp", {
                        get: function () {
                            return this._hp
                        },
                        set: function (t) {
                            var e = this
                                , o = this._hp;
                            if (this._hp = t,
                                t <= 0) {
                                if (o > 0) {
                                    if (this.ball_num > 0) {
                                        for (var n = 0; n < this.ball_num; n++)
                                            c.EventDispatch.ins().fire(c.Event_Name.GAME_CREATE_BALL);
                                        l.AudioPlayer.ins().play_sound(l.AUDIO_CONFIG.Audio_balls)
                                    }
                                    this.star_num > 0 && (c.EventDispatch.ins().fire(c.Event_Name.GAME_STAR_GET_EFFECT, this.node.x, this.node.y, this.star_num),
                                        s.default.ins().ball_power += this.star_num),
                                        this.effect_type > 0 && c.EventDispatch.ins().fire(c.Event_Name.GAME_POWER_TYPE_CHANGED, this.effect_type),
                                        c.EventDispatch.ins().fire(c.Event_Name.GAME_PLAY_BRICK_REMOVE_EFFECT, this.node.x, this.node.y, this.icon_hp_reduce.color)
                                }
                                this.node.active = !1
                            } else {
                                this.lb_hp.string = "" + (t > 1e6 ? Math.round(t / 1e6) + "M" : t > 1e3 ? Math.round(t / 1e3) + "K" : t);
                                var i = a.default.ins().theme_config[0];
                                this.icon_hp_reduce.color = this.icon.color = i ? i.color[Math.ceil(t / this._color_hp) - 1] || i.color[0] : cc.Color.WHITE,
                                    t < o && this.icon_hp_reduce.getNumberOfRunningActions() <= 0 && (this.icon_hp_reduce.active = !0,
                                        this.icon_hp_reduce.opacity = 255,
                                        this.icon_hp_reduce.runAction(cc.sequence(cc.blink(.2, 1), cc.callFunc(function () {
                                            e.icon_hp_reduce && (e.icon_hp_reduce.active = !1)
                                        }))))
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }),
                    e.prototype.onLoad = function () {
                        this.icon_power && this.icon_power.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(1, 1.2, 1.2), cc.scaleTo(1, 1, 1))))
                    }
                    ,
                    e.prototype.init = function (t, e) {
                        var o = a.default.ins().theme_config[0];
                        t = (t = t > o.color.length ? o.color.length : t) > 0 ? t : 1,
                            this._color_hp = Math.ceil(e / t),
                            this._hp = e,
                            this.hp = e,
                            this.icon_hp_reduce.active = !1,
                            this.icon_hp_reduce.stopAllActions()
                    }
                    ,
                    e.prototype.reset = function () {
                        this.node.stopAllActions(),
                            this.node.active = !1
                    }
                    ,
                    e.prototype.update = function () {
                        this.lb_hp.node.angle !== -this.node.angle && (this.lb_hp.node.angle = -this.node.angle)
                    }
                    ,
                    e.prototype.onEndContact = function (t, e, o) {
                        switch (o.tag) {
                            case 100:
                                var n = o.node.getComponent(u.default);
                                if (n && this.hp > 0) {
                                    var i = s.default.ins().ball_power * n.power_scale;
                                    i = i > this.hp ? this.hp : i,
                                        this.hp -= i,
                                        s.default.ins().score += i
                                }
                        }
                    }
                    ,
                    r([h(cc.Label)], e.prototype, "lb_hp", void 0),
                    r([h(cc.Node)], e.prototype, "icon", void 0),
                    r([h(cc.Node)], e.prototype, "icon_hp_reduce", void 0),
                    r([h(cc.Node)], e.prototype, "icon_power", void 0),
                    r([h(cc.Integer)], e.prototype, "brick_type", void 0),
                    r([h(cc.Integer)], e.prototype, "star_num", void 0),
                    r([h(cc.Integer)], e.prototype, "ball_num", void 0),
                    r([h(cc.Integer)], e.prototype, "effect_type", void 0),
                    r([h(cc.Integer)], e.prototype, "brick_radius_mul", void 0),
                    r([p], e)
            }(cc.Component);
        o.default = d,
            cc._RF.pop()
    }
        , {
        "../../common/audio/AudioPlayer": "AudioPlayer",
        "../../common/event/EventDispatch": "EventDispatch",
        "../GameConst": "GameConst",
        "../model/GameModel": "GameModel",
        "./BallItem": "BallItem"
    }],
    CommonLabelScroll: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "2b107OGN/dPgaWkAj9qT67K", "CommonLabelScroll");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        ), r = this && this.__decorate || function (t, e, o, n) {
            var i, r = arguments.length, s = r < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                s = Reflect.decorate(t, e, o, n);
            else
                for (var c = t.length - 1; c >= 0; c--)
                    (i = t[c]) && (s = (r < 3 ? i(s) : r > 3 ? i(e, o, s) : i(e, o)) || s);
            return r > 3 && s && Object.defineProperty(e, o, s),
                s
        }
            ;
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var s = t("../../common/tween/Tween")
            , c = cc._decorator
            , a = c.ccclass
            , u = c.property
            , l = function (t) {
                function e() {
                    var e = null !== t && t.apply(this, arguments) || this;
                    return e.lb_num = null,
                        e._num = {
                            value: 0
                        },
                        e
                }
                return i(e, t),
                    e.prototype.onEnable = function () {
                        this.lb_num || (this.lb_num = this.node.getComponent(cc.Label)),
                            this.initValue(this._num.value)
                    }
                    ,
                    e.prototype.initValue = function (t) {
                        this._num.value = t,
                            this.lb_num && (this.lb_num.string = "" + Math.ceil(this._num.value))
                    }
                    ,
                    e.prototype.updateValue = function (t, e) {
                        var o = this;
                        if (null != e && this.initValue(e),
                            this.lb_num)
                            if (s.Tween.removeTweens(this._num),
                                t < this._num.value)
                                t == this._num.value ? (this._num.value = t,
                                    this.lb_num.string = "" + t) : s.Tween.get(this._num, {
                                        onChange: function () {
                                            o.lb_num.string = "" + Math.ceil(o._num.value)
                                        }
                                    }).to({
                                        value: t
                                    }, 1500);
                            else {
                                var n = t - this._num.value;
                                s.Tween.get(this._num, {
                                    onChange: function () {
                                        o.lb_num.string = "" + Math.ceil(o._num.value)
                                    }
                                }).to({
                                    value: t
                                }, 300 + (n > 10 ? 700 : 0) + (n > 100 ? 500 : 0) + (n > 1e3 ? 500 : 0))
                            }
                        else
                            this._num.value = t
                    }
                    ,
                    e.prototype.onDisable = function () {
                        s.Tween.removeTweens(this._num)
                    }
                    ,
                    r([u(cc.Label)], e.prototype, "lb_num", void 0),
                    r([a], e)
            }(cc.Component);
        o.default = l,
            cc._RF.pop()
    }
        , {
        "../../common/tween/Tween": "Tween"
    }],
    EventDispatch: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "eed4aQJ7TtAqptDX40AW5tU", "EventDispatch");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        ), r = this && this.__spreadArrays || function () {
            for (var t = 0, e = 0, o = arguments.length; e < o; e++)
                t += arguments[e].length;
            var n = Array(t)
                , i = 0;
            for (e = 0; e < o; e++)
                for (var r = arguments[e], s = 0, c = r.length; s < c; s++,
                    i++)
                    n[i] = r[s];
            return n
        }
            ;
        Object.defineProperty(o, "__esModule", {
            value: !0
        }),
            o.Event_Name = o.EventDispatch = void 0;
        var s = function (t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.listeners = {},
                    e
            }
            return i(e, t),
                e.ins = function () {
                    return t.ins.call(this)
                }
                ,
                e.prototype.fire = function (t) {
                    for (var e = [], o = 1; o < arguments.length; o++)
                        e[o - 1] = arguments[o];
                    var n = this.listeners[t];
                    if (n)
                        for (var i = 0, s = n.length; i < s; i += 2) {
                            var c = n[i]
                                , a = n[i + 1];
                            c && c.call.apply(c, r([a], e))
                        }
                }
                ,
                e.prototype.add = function (t, e, o, n) {
                    void 0 === o && (o = null),
                        void 0 === n && (n = !1);
                    for (var i = [], s = 4; s < arguments.length; s++)
                        i[s - 4] = arguments[s];
                    var c = this.listeners[t];
                    c || (this.listeners[t] = c = []),
                        c.push(e, o),
                        n && e.call.apply(e, r([o], i))
                }
                ,
                e.prototype.remove = function (t, e) {
                    var o = this.listeners[t];
                    if (o) {
                        var n = o.indexOf(e);
                        n < 0 ? cc.warn("EventDispatch remove " + t + ", but cb not exists!") : o.splice(n, 2)
                    }
                }
                ,
                e.prototype.clear = function () {
                    for (var t in this.listeners)
                        this.listeners[t].length = 0;
                    this.listeners = {}
                }
                ,
                e
        }(t("../base/SingletonClass").default);
        o.EventDispatch = s,
            function (t) {
                t[t.GAME_TIME_CHANGED = 0] = "GAME_TIME_CHANGED",
                    t[t.GAME_CREATE_BALL = 1] = "GAME_CREATE_BALL",
                    t[t.GAME_SCORE_CHANGED = 2] = "GAME_SCORE_CHANGED",
                    t[t.GAME_BALL_POWER_CHANGED = 3] = "GAME_BALL_POWER_CHANGED",
                    t[t.GAME_BEST_SCORE_CHANGED = 4] = "GAME_BEST_SCORE_CHANGED",
                    t[t.GAME_ON_TOUCH_MOVE = 5] = "GAME_ON_TOUCH_MOVE",
                    t[t.GAME_POWER_TYPE_CHANGED = 6] = "GAME_POWER_TYPE_CHANGED",
                    t[t.GAME_RELIVE = 7] = "GAME_RELIVE",
                    t[t.GAME_PLAY_BRICK_REMOVE_EFFECT = 8] = "GAME_PLAY_BRICK_REMOVE_EFFECT",
                    t[t.SHOW_TIPS = 9] = "SHOW_TIPS",
                    t[t.GAME_STAR_GET_EFFECT = 10] = "GAME_STAR_GET_EFFECT"
            }(o.Event_Name || (o.Event_Name = {})),
            cc._RF.pop()
    }
        , {
        "../base/SingletonClass": "SingletonClass"
    }],
    GameConst: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "39d7ekGOCtHeZcPBzFEwSxV", "GameConst");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        );
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var r = function (t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.ball_init_x = 0,
                    e.ball_init_y = -500,
                    e.ball_speed = 1e3,
                    e.ball_radius = 15,
                    e.brick_radius = 43,
                    e.brick_init_x = 0,
                    e.brick_init_y = 500,
                    e.max_ball_init_count = 60,
                    e.max_ball_fire_speed = 10,
                    e.theme_price = 500,
                    e.sign_interval_sec = 3600,
                    e.theme_config = [{
                        color: [cc.color(255, 255, 255), cc.color(255, 255, 255), cc.color(255, 255, 255), cc.color(255, 255, 255), cc.color(255, 255, 255), cc.color(255, 255, 255), cc.color(255, 255, 255), cc.color(255, 255, 255), cc.color(255, 255, 255), cc.color(255, 255, 255)],
                        theme: "theme0"
                    }],
                    e.brick_type_percent = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 4, 5, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 9, 10],
                    e
            }
            return i(e, t),
                e.ins = function () {
                    return t.ins.call(this)
                }
                ,
                e
        }(t("../common/base/SingletonClass").default);
        o.default = r,
            cc._RF.pop()
    }
        , {
        "../common/base/SingletonClass": "SingletonClass"
    }],
    GameModel: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "cb0cdBciShMAqW7SF8LqDNi", "GameModel");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        );
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var r = t("../../common/base/SingletonClass")
            , s = t("../../common/event/EventDispatch")
            , c = function (t) {
                function e() {
                    var e = null !== t && t.apply(this, arguments) || this;
                    return e._fireBallDt = 2,
                        e._ball_power = 1,
                        e._ball_fire_speed = 2,
                        e._ball_init_count = 4,
                        e._score = 0,
                        e.bestScore = 0,
                        e._revive_times = 0,
                        e
                }
                return i(e, t),
                    e.ins = function () {
                        return t.ins.call(this)
                    }
                    ,
                    Object.defineProperty(e.prototype, "fireBallDt", {
                        get: function () {
                            return this._fireBallDt
                        },
                        set: function (t) {
                            t = t < 2 ? 2 : t,
                                this._fireBallDt = t
                        },
                        enumerable: !1,
                        configurable: !0
                    }),
                    Object.defineProperty(e.prototype, "ball_power", {
                        get: function () {
                            return this._ball_power
                        },
                        set: function (t) {
                            var e = this._ball_power;
                            t = t < 1 ? 1 : t,
                                this._ball_power = t,
                                s.EventDispatch.ins().fire(s.Event_Name.GAME_BALL_POWER_CHANGED, e, t)
                        },
                        enumerable: !1,
                        configurable: !0
                    }),
                    Object.defineProperty(e.prototype, "ball_fire_speed", {
                        get: function () {
                            return this._ball_fire_speed
                        },
                        set: function (t) {
                            t = t < 2 ? 2 : t,
                                this._ball_fire_speed = t
                        },
                        enumerable: !1,
                        configurable: !0
                    }),
                    Object.defineProperty(e.prototype, "ball_init_count", {
                        get: function () {
                            return this._ball_init_count
                        },
                        set: function (t) {
                            t = t < 4 ? 4 : t,
                                this._ball_init_count = t
                        },
                        enumerable: !1,
                        configurable: !0
                    }),
                    Object.defineProperty(e.prototype, "score", {
                        get: function () {
                            return this._score
                        },
                        set: function (t) {
                            t = t < 0 ? 0 : t;
                            var e = this._score;
                            this._score = t,
                                s.EventDispatch.ins().fire(s.Event_Name.GAME_SCORE_CHANGED, e, t)
                        },
                        enumerable: !1,
                        configurable: !0
                    }),
                    Object.defineProperty(e.prototype, "revive_times", {
                        get: function () {
                            return this._revive_times
                        },
                        set: function (t) {
                            t = t < 0 ? 0 : t,
                                this._revive_times = t
                        },
                        enumerable: !1,
                        configurable: !0
                    }),
                    e.prototype.init = function () {
                        this.reset()
                    }
                    ,
                    e.prototype.reset = function () {
                        this.score = 0,
                            this.revive_times = 0,
                            this.ball_init_count = 4,
                            this.ball_fire_speed = 1,
                            this.ball_power = 1
                    }
                    ,
                    e
            }(r.default);
        o.default = c,
            cc._RF.pop()
    }
        , {
        "../../common/base/SingletonClass": "SingletonClass",
        "../../common/event/EventDispatch": "EventDispatch"
    }],
    GameView: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "75ce10juNRO1r76kZtFyY9h", "GameView");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        ), r = this && this.__decorate || function (t, e, o, n) {
            var i, r = arguments.length, s = r < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                s = Reflect.decorate(t, e, o, n);
            else
                for (var c = t.length - 1; c >= 0; c--)
                    (i = t[c]) && (s = (r < 3 ? i(s) : r > 3 ? i(e, o, s) : i(e, o)) || s);
            return r > 3 && s && Object.defineProperty(e, o, s),
                s
        }
            ;
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var s = t("../../common/ui/pop_ui_base")
            , c = t("../item/BallItem")
            , a = t("../GameConst")
            , u = t("../model/GameModel")
            , l = t("../item/BrickItem")
            , _ = t("../../common/random/RandomUtil")
            , p = t("../../common/event/EventDispatch")
            , h = t("../../common/ui/pop_mgr")
            , d = t("../../common/audio/AudioPlayer")
            , f = t("../../common/util")
            , m = t("../../common/loader/loader_mgr")
            , v = t("../../common/tween/Tween")
            , y = cc._decorator
            , g = y.ccclass
            , b = y.property
            , E = function (t) {
                function e() {
                    var e = null !== t && t.apply(this, arguments) || this;
                    return e.bg = null,
                        e.node_top = null,
                        e.cannon_head = null,
                        e.node_physics = null,
                        e.lb_ball_count = null,
                        e.node_freeze = null,
                        e.lb_score = null,
                        e.node_power_progress = null,
                        e.power_txts = [],
                        e.balls_ins = [],
                        e.bricks_ins = [],
                        e.node_star_img = null,
                        e.star_ins = null,
                        e._star_pool = [],
                        e._star_num = 0,
                        e.balls_pool = [],
                        e.bricks_pool = [],
                        e.balls_in_game = [],
                        e.bricks_in_game = [],
                        e._updateDt = 0,
                        e._brick_speed = 1,
                        e._moved_length = 0,
                        e._moved_level = 0,
                        e._power_type = 0,
                        e._isGameOver = !1,
                        e._brick_img_pool = [],
                        e
                }
                return i(e, t),
                    e.prototype.onLoad = function () {
                        this.bg.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this),
                            cc.director.getPhysicsManager().enabled = !0;
                        for (var t = 0, e = this.balls_ins.length; t < e;)
                            this.balls_pool[t++] = [];
                        for (t = 0,
                            e = this.bricks_ins.length; t < e;)
                            this.bricks_pool[t++] = [];
                        cc.director.getPhysicsManager().enabledAccumulator = !0
                    }
                    ,
                    e.prototype.onTouchMove = function (t) {
                        var e = t.getDeltaX()
                            , o = t.getDeltaY()
                            , n = .3 * Math.sqrt(e * e + o * o)
                            , i = Math.sign(e)
                            , r = -this.cannon_head.angle + n * i;
                        r = Math.abs(r) >= 85 ? 85 * Math.sign(r) : r,
                            this.cannon_head.angle = -r
                    }
                    ,
                    e.prototype.update = function () {
                        var t = this;
                        if (!this._isGameOver) {
                            if (this._power_type > 0)
                                switch (this.node_power_progress.width -= 1.5,
                                this.node_power_progress.active && this.node_power_progress.width <= 0 && this.updateGamePowerType(0),
                                this._power_type) {
                                    case 3:
                                        this._brick_speed = 0
                                }
                            this._updateDt++,
                                this._moved_length += this._brick_speed,
                                this._updateDt % u.default.ins().fireBallDt != 0 && 2 !== this._power_type || this.balls_in_game.some(function (e) {
                                    return e.ball_status === c.EnumBallStatus.onReady && (0 === e.ball_type || 2 === t._power_type) && (e.power_scale = 1 === t._power_type ? 2 : 1,
                                        e.fireBall(-t.cannon_head.angle),
                                        !0)
                                });
                            var e = a.default.ins().brick_radius
                                , o = u.default.ins().ball_power;
                            if (Math.floor(this._moved_length / 4 / e) > this._moved_level) {
                                this._moved_level++;
                                var n = this.balls_in_game.length / (2 === this._power_type ? 2 : 1)
                                    , i = Math.ceil(n * o * .5 + this._moved_level * o * 1.2)
                                    , r = a.default.ins().brick_type_percent
                                    , s = -999
                                    , l = -999
                                    , p = -999;
                                this._moved_level % 12 == 0 && (s = _.RandomUtil.ins().randomNum(-2, 3),
                                    this.createBrick(s * e * 2 - e + a.default.ins().brick_init_x, e + a.default.ins().brick_init_y, _.RandomUtil.ins().randomNum(3 * i, 6 * i), _.RandomUtil.ins().randomNum(14, 16), 10)),
                                    this._moved_level % 11 == 0 && (l = _.RandomUtil.ins().randomNum(0, 1),
                                        p = _.RandomUtil.ins().randomNum(-3, 3));
                                for (var h = 0; h < 2; h++)
                                    for (var d = -3; d < 4; d++)
                                        if (d === s || d === s - 1)
                                            ;
                                        else {
                                            var f = h === l && d === p ? _.RandomUtil.ins().randomNum(o, Math.ceil(i / 2)) : _.RandomUtil.ins().randomNum(-Math.round(i / (this._moved_level % 5 + 1)), i)
                                                , m = h === l && d === p ? _.RandomUtil.ins().randomNum(11, 13) : r[_.RandomUtil.ins().randomNum(0, r.length - 1)];
                                            f >= o && this.createBrick(d * e * 2 + a.default.ins().brick_init_x, h * e * 2 + a.default.ins().brick_init_y, f, m, Math.ceil(10 * f / i))
                                        }
                            }
                            for (var v = 9999, y = 0, g = this.bricks_in_game.length; y < g; y++) {
                                var b = this.bricks_in_game[y];
                                if (b && b.node) {
                                    var E = b.node;
                                    if (b.hp <= 0 || !E.active)
                                        this._updateDt % 60 == 0 && (b.reset(),
                                            this.bricks_in_game.splice(y, 1),
                                            this.bricks_pool[b.brick_type].push(E),
                                            y--);
                                    else {
                                        if (E.y -= this._brick_speed,
                                            E.y - b.brick_radius_mul * e <= a.default.ins().ball_init_y)
                                            return void this.gameOver();
                                        E.y < v && (v = E.y)
                                    }
                                }
                            }
                            this._brick_speed = v > a.default.ins().ball_init_y + 7 * e ? 1 : v > a.default.ins().ball_init_y + 5 * e ? .9 : .6
                        }
                    }
                    ,
                    e.prototype.createBall = function (t, e, o, n) {
                        void 0 === t && (t = a.default.ins().ball_init_x),
                            void 0 === e && (e = a.default.ins().ball_init_y),
                            void 0 === o && (o = c.EnumBallStatus.onReady),
                            void 0 === n && (n = 0);
                        var i = this.balls_pool[n].shift();
                        i || (i = cc.instantiate(this.balls_ins[n]),
                            this.node_physics.addChild(i));
                        var r = i.getComponent(c.default);
                        r.init(t, e, o),
                            i.active = !0,
                            this.balls_in_game.unshift(r),
                            this.lb_ball_count.string = "" + this.balls_in_game.length / 2,
                            0 === n && this.createBall(a.default.ins().ball_init_x, a.default.ins().ball_init_y, c.EnumBallStatus.onReady, 1)
                    }
                    ,
                    e.prototype.createBrick = function (t, e, o, n, i) {
                        void 0 === t && (t = a.default.ins().brick_init_x),
                            void 0 === e && (e = a.default.ins().brick_init_y),
                            void 0 === o && (o = 1),
                            void 0 === n && (n = 0),
                            void 0 === i && (i = 1),
                            7 === n && this.balls_in_game.length > 200 && (n = 0);
                        var r = this.bricks_pool[n].shift();
                        r || (r = cc.instantiate(this.bricks_ins[n]),
                            this.node_physics.addChild(r));
                        var s = r.getComponent(l.default);
                        r.active = !0,
                            r.x = t,
                            r.y = e,
                            s.init(i, o),
                            this.bricks_in_game.push(s)
                    }
                    ,
                    e.prototype.resetGame = function () {
                        this.node_physics.active = !0,
                            this.cannon_head.angle = 10 - 20 * Math.random(),
                            cc.director.getPhysicsManager().enabled = !0,
                            this._updateDt = 0,
                            this._moved_length = 0,
                            this._moved_level = 0,
                            this._isGameOver = !1,
                            this.updateGamePowerType(0),
                            u.default.ins().reset();
                        for (var t = u.default.ins().ball_init_count, e = 0; e < t; e++)
                            this.createBall();
                        for (var o = a.default.ins().brick_radius, n = 0; n < 2; n++)
                            for (var i = -3; i < 4; i++) {
                                var r = (n + 1) * u.default.ins().ball_power + (t - 4);
                                r = r < 0 ? 1 : r,
                                    this.createBrick(i * o * 2 + a.default.ins().brick_init_x, n * o * 2 + a.default.ins().brick_init_y, r)
                            }
                        this._star_num = u.default.ins().ball_power
                    }
                    ,
                    e.prototype.clearGame = function () {
                        var t = this;
                        this.node_physics.active = !1,
                            cc.director.getPhysicsManager().enabled = !1,
                            this.balls_in_game.forEach(function (e) {
                                e.reset(),
                                    t.balls_pool[e.ball_type].push(e.node)
                            }),
                            this.balls_in_game = [],
                            this.bricks_in_game.forEach(function (e) {
                                e.reset(),
                                    t.bricks_pool[e.brick_type].push(e.node)
                            }),
                            this.bricks_in_game = [],
                            u.default.ins().reset()
                    }
                    ,
                    e.prototype.updateScore = function () {
                        var t = u.default.ins().score;
                        this.lb_score.string = "" + t
                        try {
                            __acp._eventAds.emit("game_score", { score: t })
                        } catch (error) {}
                    }
                    ,
                    e.prototype.updateBallPower = function () {
                        u.default.ins().ball_power
                    }
                    ,
                    e.prototype.playBrickDeleteEffect = function (t, e, o) {
                        var n = this
                            , i = a.default.ins().theme_config[0];
                        i && m.loader_mgr.get_inst().loadAsset("texture/plist/customize", f.gen_handler(function (r) {
                            var s = r.getSpriteFrame(i.theme);
                            if (s)
                                for (var c = function (i) {
                                    var r = i % 3 - 1.5
                                        , c = Math.floor(i / 3) - 1.5
                                        , a = t + r * (100 + 150 * Math.random())
                                        , u = e + c * (100 + 150 * Math.random())
                                        , l = n._brick_img_pool.shift();
                                    l || ((l = new cc.Node).addComponent(cc.Sprite),
                                        n.node_physics.addChild(l)),
                                        l.active = !0,
                                        l.angle = 0,
                                        l.getComponent(cc.Sprite).spriteFrame = s,
                                        l.color = o;
                                    var _ = 50 * Math.random() + 50;
                                    l.width = l.height = _,
                                        l.x = t,
                                        l.y = e,
                                        v.Tween.get(l).to({
                                            x: a,
                                            y: u,
                                            width: _ / 3,
                                            height: _ / 3,
                                            angle: 1e3 * Math.random()
                                        }, 500 * Math.random() + 500).call(function () {
                                            l.active = !1,
                                                n._brick_img_pool.push(l)
                                        })
                                }, a = 0; a < 9; a++)
                                    c(a)
                        }), cc.SpriteAtlas)
                    }
                    ,
                    e.prototype.updateGamePowerType = function (t) {
                        if (void 0 === t && (t = 0),
                            t > 0) {
                            if (0 === this._power_type) {
                                switch (this.node_power_progress.active = !0,
                                this.node_power_progress.width = 640,
                                this._power_type = t,
                                t) {
                                    case 1:
                                        d.AudioPlayer.ins().play_sound(d.AUDIO_CONFIG.Audio_mega);
                                        break;
                                    case 2:
                                        d.AudioPlayer.ins().play_sound(d.AUDIO_CONFIG.Audio_speed),
                                            this.cannon_head.scale = 1.5;
                                        break;
                                    case 3:
                                        d.AudioPlayer.ins().play_sound(d.AUDIO_CONFIG.Audio_freeze),
                                            this.node_freeze.active = !0
                                }
                                this.lb_ball_count.node.color = this.node_power_progress.color = [cc.Color.WHITE, cc.Color.RED, cc.Color.YELLOW, cc.Color.GRAY][t] || cc.Color.WHITE;
                                var e = this.power_txts[t];
                                e && (e.active = !0,
                                    e.stopAllActions(),
                                    e.opacity = 0,
                                    e.runAction(cc.sequence(cc.fadeIn(1), cc.moveBy(.5, 0, 100), cc.delayTime(.5), cc.fadeOut(.8), cc.callFunc(function () {
                                        e && (e.y -= 100,
                                            e.active = !1)
                                    }))))
                            }
                        } else
                            this.node_freeze.active = this.node_power_progress.active = !1,
                                this.node_power_progress.width = 640,
                                this.lb_ball_count.node.color = cc.Color.WHITE,
                                this.cannon_head.scale = 1,
                                this._power_type,
                                this._power_type = t
                    }
                    ,
                    e.prototype.gameRelive = function () {
                        var t = this;
                        u.default.ins().revive_times++,
                            this.bricks_in_game.forEach(function (e) {
                                e.reset(),
                                    t.bricks_pool[e.brick_type].push(e.node)
                            }),
                            this.bricks_in_game = [],
                            this._isGameOver = !1,
                            cc.director.getPhysicsManager().enabled = !0,
                            d.AudioPlayer.ins().play_music(d.AUDIO_CONFIG.Audio_Bgm)
                    }
                    ,
                    e.prototype.gameOver = function () {
                        this._isGameOver = !0,
                            cc.director.getPhysicsManager().enabled = !1,
                            h.pop_mgr.get_inst().show(h.UI_CONFIG.result)
                    }
                    ,
                    e.prototype.on_show = function () {
                        t.prototype.on_show.call(this),
                            p.EventDispatch.ins().add(p.Event_Name.GAME_CREATE_BALL, this.createBall, this),
                            p.EventDispatch.ins().add(p.Event_Name.GAME_RELIVE, this.gameRelive, this),
                            p.EventDispatch.ins().add(p.Event_Name.GAME_ON_TOUCH_MOVE, this.onTouchMove, this),
                            p.EventDispatch.ins().add(p.Event_Name.GAME_POWER_TYPE_CHANGED, this.updateGamePowerType, this),
                            p.EventDispatch.ins().add(p.Event_Name.GAME_SCORE_CHANGED, this.updateScore, this, !0),
                            p.EventDispatch.ins().add(p.Event_Name.GAME_BALL_POWER_CHANGED, this.updateBallPower, this, !0),
                            p.EventDispatch.ins().add(p.Event_Name.GAME_PLAY_BRICK_REMOVE_EFFECT, this.playBrickDeleteEffect, this),
                            d.AudioPlayer.ins().play_music(d.AUDIO_CONFIG.Audio_Bgm),
                            this.resetGame()
                    }
                    ,
                    e.prototype.onCloseBtnTouch = function () {
                        t.prototype.onCloseBtnTouch.call(this),
                            h.pop_mgr.get_inst().hide(h.UI_CONFIG.instruction)
                    }
                    ,
                    e.prototype.on_hide = function () {
                        p.EventDispatch.ins().remove(p.Event_Name.GAME_CREATE_BALL, this.createBall),
                            p.EventDispatch.ins().remove(p.Event_Name.GAME_RELIVE, this.gameRelive),
                            p.EventDispatch.ins().remove(p.Event_Name.GAME_ON_TOUCH_MOVE, this.onTouchMove),
                            p.EventDispatch.ins().remove(p.Event_Name.GAME_POWER_TYPE_CHANGED, this.updateGamePowerType),
                            p.EventDispatch.ins().remove(p.Event_Name.GAME_SCORE_CHANGED, this.updateScore),
                            p.EventDispatch.ins().remove(p.Event_Name.GAME_PLAY_BRICK_REMOVE_EFFECT, this.playBrickDeleteEffect),
                            d.AudioPlayer.ins().stop_music(),
                            this.clearGame(),
                            t.prototype.on_hide.call(this)
                    }
                    ,
                    r([b(cc.Node)], e.prototype, "bg", void 0),
                    r([b(cc.Node)], e.prototype, "node_top", void 0),
                    r([b(cc.Node)], e.prototype, "cannon_head", void 0),
                    r([b(cc.Node)], e.prototype, "node_physics", void 0),
                    r([b(cc.Label)], e.prototype, "lb_ball_count", void 0),
                    r([b(cc.Node)], e.prototype, "node_freeze", void 0),
                    r([b(cc.Label)], e.prototype, "lb_score", void 0),
                    r([b(cc.Node)], e.prototype, "node_power_progress", void 0),
                    r([b([cc.Node])], e.prototype, "power_txts", void 0),
                    r([b([cc.Prefab])], e.prototype, "balls_ins", void 0),
                    r([b([cc.Prefab])], e.prototype, "bricks_ins", void 0),
                    r([b(cc.Node)], e.prototype, "node_star_img", void 0),
                    r([b(cc.Prefab)], e.prototype, "star_ins", void 0),
                    r([g], e)
            }(s.POP_UI_BASE);
        o.default = E,
            cc._RF.pop()
    }
        , {
        "../../common/audio/AudioPlayer": "AudioPlayer",
        "../../common/event/EventDispatch": "EventDispatch",
        "../../common/loader/loader_mgr": "loader_mgr",
        "../../common/random/RandomUtil": "RandomUtil",
        "../../common/tween/Tween": "Tween",
        "../../common/ui/pop_mgr": "pop_mgr",
        "../../common/ui/pop_ui_base": "pop_ui_base",
        "../../common/util": "util",
        "../GameConst": "GameConst",
        "../item/BallItem": "BallItem",
        "../item/BrickItem": "BrickItem",
        "../model/GameModel": "GameModel"
    }],
    LocalStorage: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "268f8O0nHBNeLgcPVchYcOV", "LocalStorage");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        );
        Object.defineProperty(o, "__esModule", {
            value: !0
        }),
            o.CONST_STORAGE_KEY = o.LocalStorage = void 0;
        var r = function (t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e._game_key = "nonstop_balls_tt_",
                    e
            }
            return i(e, t),
                e.ins = function () {
                    return t.ins.call(this)
                }
                ,
                e.prototype.setLocal = function (t, e) {
                    try {
                        "object" == typeof e && (e = JSON.stringify(e)),
                            cc.sys.localStorage.setItem(this.str_encrypt(this._game_key + t), this.str_encrypt(e, this._game_key + t))
                    } catch (o) { }
                }
                ,
                e.prototype.getLocal = function (t, e) {
                    try {
                        var o = cc.sys.localStorage.getItem(this.str_encrypt(this._game_key + t));
                        if (null == o)
                            return e;
                        switch (o = this.str_decrypt(o, this._game_key + t),
                        typeof e) {
                            case "object":
                                var n = e;
                                try {
                                    var i = JSON.parse(o);
                                    "object" == typeof i && (n = i)
                                } catch (r) { }
                                return n;
                            case "boolean":
                                return "true" === o;
                            case "number":
                                return Number(o) || e
                        }
                        return o
                    } catch (s) {
                        return e
                    }
                }
                ,
                e.prototype.str_encrypt = function (t, e) {
                    void 0 === e && (e = this._game_key);
                    for (var o = 0, n = 0, i = e.length; n < i; n++)
                        o += e.charCodeAt(n);
                    t = t.toString(),
                        t += e;
                    for (var r = String.fromCharCode(t.charCodeAt(0) + t.length * o), s = 1; s < t.length; s++)
                        r += String.fromCharCode(t.charCodeAt(s) + t.charCodeAt(s - 1));
                    return encodeURIComponent(r)
                }
                ,
                e.prototype.str_decrypt = function (t, e) {
                    void 0 === e && (e = this._game_key);
                    for (var o = 0, n = 0, i = e.length; n < i; n++)
                        o += e.charCodeAt(n);
                    t = t.toString(),
                        t = decodeURIComponent(t);
                    for (var r = String.fromCharCode(t.charCodeAt(0) - t.length * o), s = 1; s < t.length; s++)
                        r += String.fromCharCode(t.charCodeAt(s) - r.charCodeAt(s - 1));
                    return r.slice(0, r.length - e.length)
                }
                ,
                e
        }(t("../base/SingletonClass").default);
        o.LocalStorage = r,
            o.CONST_STORAGE_KEY = {
                KEY_MUSIC_VOLUME: "KEY_MUSIC_VOLUME",
                KEY_SOUND_VOLUME: "KEY_SOUND_VOLUME",
                KEY_SOUND_IS_MUTE: "KEY_SOUND_IS_MUTE",
                KEY_MUSIC_IS_MUTE: "KEY_MUSIC_IS_MUTE"
            },
            cc._RF.pop()
    }
        , {
        "../base/SingletonClass": "SingletonClass"
    }],
    Main: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "d11441zdgFEV5MkeWy6aa9W", "Main");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        ), r = this && this.__decorate || function (t, e, o, n) {
            var i, r = arguments.length, s = r < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                s = Reflect.decorate(t, e, o, n);
            else
                for (var c = t.length - 1; c >= 0; c--)
                    (i = t[c]) && (s = (r < 3 ? i(s) : r > 3 ? i(e, o, s) : i(e, o)) || s);
            return r > 3 && s && Object.defineProperty(e, o, s),
                s
        }
            ;
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var s = t("../common/ui/pop_mgr")
            , c = t("../common/timer/timer_mgr")
            , a = t("../common/random/RandomUtil")
            , u = t("./model/GameModel")
            , l = t("../common/audio/AudioPlayer")
            , _ = cc._decorator
            , p = _.ccclass
            , h = _.property
            , d = function (t) {
                function e() {
                    var e = null !== t && t.apply(this, arguments) || this;
                    return e.bg_tips = null,
                        e.lb_tips = null,
                        e.top_layer = null,
                        e
                }
                return i(e, t),
                    e.prototype.onLoad = function () {
                        a.RandomUtil.ins().init(Math.round(1e6 + 8999999 * Math.random()).toString()),
                            l.AudioPlayer.ins().init(),
                            u.default.ins().init(),
                            s.pop_mgr.get_inst().show(s.UI_CONFIG.menu),
                            cc.sys.localStorage.setItem("bool", JSON.stringify("1"));
                        try {
                            var t = l.AudioPlayer.ins()
                                , e = function () {
                                    try {
                                        t.pause_by_game && t.pause_by_game()
                                    } catch (t) { }
                                }
                                , o = function () {
                                    try {
                                        t.resume_by_game && t.resume_by_game()
                                    } catch (t) { }
                                };
                            cc.director && !cc.director.__acp_audio_pause_patch && (cc.director.__acp_audio_pause_patch = !0,
                                function () {
                                    var t = cc.director.pause
                                        , n = cc.director.resume;
                                    "function" == typeof t && (cc.director.pause = function () {
                                        return e(),
                                            t.apply(cc.director, arguments)
                                    }
                                    ),
                                        "function" == typeof n && (cc.director.resume = function () {
                                            var t = n.apply(cc.director, arguments);
                                            return o(),
                                                t
                                        }
                                        )
                                }());
                            cc.game && cc.game.on && (cc.game.on(cc.game.EVENT_HIDE, e),
                                cc.game.on(cc.game.EVENT_SHOW, function () {
                                    try {
                                        if (cc.director && "function" == typeof cc.director.isPaused && cc.director.isPaused())
                                            return
                                    } catch (t) { }
                                    o()
                                }))
                        } catch (t) { }
                    }
                    ,
                    e.prototype.update = function (t) {
                        c.TimerMgr.getInst().update(t)
                    }
                    ,
                    r([h(cc.Node)], e.prototype, "bg_tips", void 0),
                    r([h(cc.Label)], e.prototype, "lb_tips", void 0),
                    r([h(cc.Node)], e.prototype, "top_layer", void 0),
                    r([p], e)
            }(cc.Component);
        o.default = d,
            cc._RF.pop()
    }
        , {
        "../common/audio/AudioPlayer": "AudioPlayer",
        "../common/random/RandomUtil": "RandomUtil",
        "../common/timer/timer_mgr": "timer_mgr",
        "../common/ui/pop_mgr": "pop_mgr",
        "./model/GameModel": "GameModel"
    }],
    MenuView: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "fbe8dywH6JCwbmwYsARWyMe", "MenuView");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        ), r = this && this.__decorate || function (t, e, o, n) {
            var i, r = arguments.length, s = r < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                s = Reflect.decorate(t, e, o, n);
            else
                for (var c = t.length - 1; c >= 0; c--)
                    (i = t[c]) && (s = (r < 3 ? i(s) : r > 3 ? i(e, o, s) : i(e, o)) || s);
            return r > 3 && s && Object.defineProperty(e, o, s),
                s
        }
            ;
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var s = t("../../common/ui/pop_ui_base")
            , c = t("../../common/ui/pop_mgr")
            , a = t("../../common/event/EventDispatch")
            , u = t("../../common/audio/AudioPlayer")
            , l = cc._decorator
            , _ = l.ccclass
            , p = l.property
            , h = function (t) {
                function e() {
                    var e = null !== t && t.apply(this, arguments) || this;
                    return e.btn_play = null,
                        e.highscore = null,
                        e.btn_sound = null,
                        e.btn_music = null,
                        e.preload_prefabs = [],
                        e
                }
                return i(e, t),
                    e.prototype.onLoad = function () {
                        this.btn_play.on(cc.Node.EventType.TOUCH_END, this.loading, this),
                            this.btn_play.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this),
                            u.AudioPlayer.ins().get_sound_mute() ? this.btn_sound.check() : this.btn_sound.uncheck(),
                            u.AudioPlayer.ins().get_music_mute() ? this.btn_music.check() : this.btn_music.uncheck(),
                            this.btn_sound.node.on("toggle", this.soundChange, this),
                            this.btn_music.node.on("toggle", this.musicChange, this)
                    }
                    ,
                    e.prototype.soundChange = function () {
                        var t = this.btn_sound.isChecked;
                        u.AudioPlayer.ins().set_sound_mute(t)
                    }
                    ,
                    e.prototype.musicChange = function () {
                        var t = this.btn_music.isChecked;
                        u.AudioPlayer.ins().set_music_mute(t)
                    }
                    ,
                    e.prototype.loading = function () {
                        c.pop_mgr.get_inst().show(c.UI_CONFIG.instruction),
                            u.AudioPlayer.ins().play_sound(u.AUDIO_CONFIG.Audio_Btn)
                    }
                    ,
                    e.prototype.onTouchMove = function (t) {
                        a.EventDispatch.ins().fire(a.Event_Name.GAME_ON_TOUCH_MOVE, t)
                    }
                    ,
                    e.prototype.openCustomizeView = function () {
                        c.pop_mgr.get_inst().show(c.UI_CONFIG.customize)
                    }
                    ,
                    e.prototype.update = function () {
                        if ("1" == JSON.parse(cc.sys.localStorage.getItem("bool"))) {
                            var t = JSON.parse(cc.sys.localStorage.getItem("highscore"));
                            this.highscore.string = t,
                                console.log(t)
                        }
                        cc.sys.localStorage.setItem("bool", JSON.stringify("0"))
                    }
                    ,
                    r([p(cc.Node)], e.prototype, "btn_play", void 0),
                    r([p(cc.Label)], e.prototype, "highscore", void 0),
                    r([p(cc.Toggle)], e.prototype, "btn_sound", void 0),
                    r([p(cc.Toggle)], e.prototype, "btn_music", void 0),
                    r([p([cc.Prefab])], e.prototype, "preload_prefabs", void 0),
                    r([_], e)
            }(s.POP_UI_BASE);
        o.default = h,
            cc._RF.pop()
    }
        , {
        "../../common/audio/AudioPlayer": "AudioPlayer",
        "../../common/event/EventDispatch": "EventDispatch",
        "../../common/ui/pop_mgr": "pop_mgr",
        "../../common/ui/pop_ui_base": "pop_ui_base"
    }],
    RandomUtil: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "9dcebZ21S1CcoCfjaM6tclf", "RandomUtil");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        );
        Object.defineProperty(o, "__esModule", {
            value: !0
        }),
            o.RandomUtil = o.RandomSeedType = void 0;
        var r, s = t("../base/SingletonClass");
        (function (t) {
            t[t.UNDEFINED = 0] = "UNDEFINED"
        }
        )(r = o.RandomSeedType || (o.RandomSeedType = {}));
        var c = function (t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e._seeds = [],
                    e._seedIndex = [],
                    e._selectedIndexes = [],
                    e._randomSeed = "0123456789abcdef",
                    e
            }
            return i(e, t),
                e.ins = function () {
                    return t.ins.call(this)
                }
                ,
                e.prototype.init = function (t) {
                    void 0 === t && (t = "0123456789abcdef"),
                        this._randomSeed = t,
                        this._seeds = [],
                        this._selectedIndexes = [],
                        this._seedIndex = [];
                    for (var e = 0, o = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]; e < o.length; e++) {
                        var n = o[e];
                        this.resetSeed(n)
                    }
                }
                ,
                e.prototype.resetSeed = function (t) {
                    this._seeds[t] = [],
                        this._selectedIndexes[t] = [],
                        this._seedIndex[t] = 0;
                    for (var e = 0; e < this._randomSeed.length; e++) {
                        var o = parseInt(this._randomSeed[e], 36) || 0;
                        o = (9301 * o + 49297) % 10485763 || 0,
                            this._seeds[t].push(o)
                    }
                }
                ,
                e.prototype.randomNum = function (t, e, o) {
                    void 0 === o && (o = r.UNDEFINED),
                        t > e && (e = t);
                    var n = this._seedIndex[o] % this._randomSeed.length
                        , i = t + this._seeds[o][n] % (e - t + 1);
                    return this._seeds[o][n] = (9301 * this._seeds[o][n] + 49297) % 10485763 || 0,
                        this._seedIndex[o]++,
                        this._selectedIndexes[o].push(i),
                        i
                }
                ,
                e.prototype.randomNumArray = function (t, e, o, n) {
                    void 0 === n && (n = r.UNDEFINED),
                        t > e && (e = t);
                    var i = [];
                    e - t + 1 < o && (o = e - t + 1);
                    for (var s = 0; s < o;) {
                        var c = this.randomNum(t, e, n);
                        i.indexOf(c) < 0 && (i.push(c),
                            s++)
                    }
                    return i
                }
                ,
                e.prototype.getPercentProbability = function (t, e) {
                    return void 0 === e && (e = r.UNDEFINED),
                        t >= this.randomNum(1, 100, e)
                }
                ,
                e
        }(s.default);
        o.RandomUtil = c,
            cc._RF.pop()
    }
        , {
        "../base/SingletonClass": "SingletonClass"
    }],
    ResultView: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "70743Uwb81FW7HSepgHlXBr", "ResultView");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        ), r = this && this.__decorate || function (t, e, o, n) {
            var i, r = arguments.length, s = r < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                s = Reflect.decorate(t, e, o, n);
            else
                for (var c = t.length - 1; c >= 0; c--)
                    (i = t[c]) && (s = (r < 3 ? i(s) : r > 3 ? i(e, o, s) : i(e, o)) || s);
            return r > 3 && s && Object.defineProperty(e, o, s),
                s
        }
            ;
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var s = t("../../common/ui/pop_mgr")
            , c = t("../../common/ui/pop_ui_base")
            , a = t("../model/GameModel")
            , u = t("../../common/audio/AudioPlayer")
            , l = t("../../common/event/EventDispatch")
            , _ = cc._decorator
            , p = _.ccclass
            , h = _.property
	            , d = function (t) {
	                function e() {
	                    var e = t.call(this) || this;
	                    return e.btn_reset = null,
	                        e.btn_revive = null,
	                        e.btn_revive_back = null,
	                        e.lb_revive_count = null,
	                        e.node_no_revive = null,
	                        e.node_revive = null,
	                        e.btn_share = null,
	                        e.lb_score = null,
	                        e.btn_replay = null,
	                        e._sound = [u.AUDIO_CONFIG.Audio_gameover, u.AUDIO_CONFIG.Audio_win, u.AUDIO_CONFIG.Audio_congra],
	                        e._autoReviveCount = 5,
	                        e._gameOverReported = !1,
	                        e
	                }
	                return i(e, t),
	                    e.prototype.reportGameOver = function () {
	                        this._gameOverReported || (this._gameOverReported = !0,
	                            function () { try { __acp._eventAds.emit("game_over", { value: 1 }) } catch (error) { } }())
	                    }
	                    ,
	                    e.prototype.onLoad = function () {
	                        this.btn_reset.on(cc.Node.EventType.TOUCH_END, this.backToMenu, this),
	                            this.btn_revive.on(cc.Node.EventType.TOUCH_END, this.gameRevive, this),
	                            this.btn_revive_back.on(cc.Node.EventType.TOUCH_END, this.closeGameRevive, this),
	                            this.btn_share.on(cc.Node.EventType.TOUCH_END, this.share, this),
	                            this.btn_replay.on(cc.Node.EventType.TOUCH_END, this.replay, this)
	                    }
	                    ,
	                    e.prototype.backToMenu = function () {
	                        this.reportGameOver && this.reportGameOver();
	                        try {
	                            try {
	                                cc.director.pause()
	                            } catch (e) { }
	                            __acp.showAd().then(() => {
                                try {
                                    cc.director.resume()
                                } catch (e) { }
                                this.onCloseBtnTouch(),
                                    s.pop_mgr.get_inst().hide(s.UI_CONFIG.game),
                                    s.pop_mgr.get_inst().hide(s.UI_CONFIG.instruction)
                            }).catch(() => {
                                try {
                                    cc.director.resume()
                                } catch (e) { }
                                this.onCloseBtnTouch(),
                                    s.pop_mgr.get_inst().hide(s.UI_CONFIG.game),
                                    s.pop_mgr.get_inst().hide(s.UI_CONFIG.instruction)
                            })

                        } catch (error) {
                            try {
                                cc.director.resume()
                            } catch (e) { }
                            this.onCloseBtnTouch(),
                                s.pop_mgr.get_inst().hide(s.UI_CONFIG.game),
                                s.pop_mgr.get_inst().hide(s.UI_CONFIG.instruction)
                        }


	                    }
	                    ,
	                    e.prototype.replay = function () {
	                        this.reportGameOver && this.reportGameOver();
	                        try {
	                            try {
	                                cc.director.pause()
	                            } catch (e) { }
	                            __acp.showAd().then(() => {
                                try {
                                    cc.director.resume()
                                } catch (e) { }
                                this.onCloseBtnTouch(),
                                    s.pop_mgr.get_inst().hide(s.UI_CONFIG.result),
                                    s.pop_mgr.get_inst().hide(s.UI_CONFIG.game)
                            }).catch(() => {
                                try {
                                    cc.director.resume()
                                } catch (e) { }
                                this.onCloseBtnTouch(),
                                    s.pop_mgr.get_inst().hide(s.UI_CONFIG.result),
                                    s.pop_mgr.get_inst().hide(s.UI_CONFIG.game)
                            })
                        } catch (error) {
                            try {
                                cc.director.resume()
                            } catch (e) { }
                            this.onCloseBtnTouch(),
                                s.pop_mgr.get_inst().hide(s.UI_CONFIG.result),
                                s.pop_mgr.get_inst().hide(s.UI_CONFIG.game)
                        }

                    }
                    ,
                    e.prototype.share = function () {
                        l.EventDispatch.ins().fire(l.Event_Name.SHOW_TIPS, "\u5206\u4eab\u5931\u8d25")
	                    }
	                    ,
	                    e.prototype.closeGameRevive = function () {
	                        this.updateCanRevive(!1)
	                    }
	                    ,
	                    e.prototype.gameRevive = function () {
	                        try {
	                            try {
                                cc.director.pause()
	                            } catch (e) { }
	                            __acp.showAd("rewarded").then(() => {
	                                try {
	                                    cc.director.resume()
	                                } catch (e) { }
	                                try {
	                                    this.unschedule(this.autoReviveCountFn)
	                                } catch (e) { }
	                                l.EventDispatch.ins().fire(l.Event_Name.GAME_RELIVE),
	                                    this.onCloseBtnTouch()
	                            }).catch(() => {
	                                try {
                                    cc.director.resume()
                                } catch (e) { }
                            })
                        } catch (e) {
                            try {
                                cc.director.resume()
                            } catch (e2) { }
                        }
	                    }
	                    ,
	                    e.prototype.updateCanRevive = function (t) {
	                        this.node_revive.active = t,
	                            this.node_no_revive.active = !t,
	                            t ? (this._autoReviveCount = 5,
	                                this.autoReviveCountFn(),
	                                this.schedule(this.autoReviveCountFn, 1, this._autoReviveCount + 1, 0)) : (this.unschedule(this.autoReviveCountFn),
	                                    this.reportGameOver && this.reportGameOver())
	                    }
	                    ,
	                    e.prototype.autoReviveCountFn = function () {
	                        this._autoReviveCount--,
	                            this.lb_revive_count.string = "" + this._autoReviveCount,
                            this._autoReviveCount <= 0 && this.closeGameRevive()
                    }
	                    ,
	                    e.prototype.on_show = function () {
	                        t.prototype.on_show.call(this);
	                        this._gameOverReported = !1;
	                        var e = a.default.ins().score;
	                        e > a.default.ins().bestScore && (a.default.ins().bestScore = e),
	                            this.lb_score.string = "" + e,
	                            cc.sys.localStorage.setItem("highscore", JSON.stringify(this.lb_score.string)),
                            cc.sys.localStorage.setItem("bool", JSON.stringify("1")),
                            u.AudioPlayer.ins().play_sound(this._sound[Math.floor(Math.random() * this._sound.length)] || this._sound[0]),
                            a.default.ins().revive_times < 1 ? this.updateCanRevive(!0) : this.updateCanRevive(!1)
                    }
                    ,
                    e.prototype.on_hide = function () {
                        t.prototype.on_hide.call(this)
                    }
	                    ,
	                    e.prototype.update = function () {
	                        // legacy banner-based revive flow removed; reward revive is handled in `gameRevive()`.
	                    }
	                    ,
	                    r([h(cc.Node)], e.prototype, "btn_reset", void 0),
	                    r([h(cc.Node)], e.prototype, "btn_revive", void 0),
                    r([h(cc.Node)], e.prototype, "btn_revive_back", void 0),
                    r([h(cc.Label)], e.prototype, "lb_revive_count", void 0),
                    r([h(cc.Node)], e.prototype, "node_no_revive", void 0),
                    r([h(cc.Node)], e.prototype, "node_revive", void 0),
                    r([h(cc.Node)], e.prototype, "btn_share", void 0),
                    r([h(cc.Label)], e.prototype, "lb_score", void 0),
                    r([h(cc.Node)], e.prototype, "btn_replay", void 0),
                    r([p], e)
            }(c.POP_UI_BASE);
        o.default = d,
            cc._RF.pop()
    }
        , {
        "../../common/audio/AudioPlayer": "AudioPlayer",
        "../../common/event/EventDispatch": "EventDispatch",
        "../../common/ui/pop_mgr": "pop_mgr",
        "../../common/ui/pop_ui_base": "pop_ui_base",
        "../model/GameModel": "GameModel"
    }],
    SingletonClass: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "67b6bxkrdtJJph7b4mJgN8P", "SingletonClass"),
            Object.defineProperty(o, "__esModule", {
                value: !0
            });
        var n = function () {
            function t() { }
            return t.ins = function () {
                return this._ins || (this._ins = new this),
                    this._ins
            }
                ,
                t
        }();
        o.default = n,
            cc._RF.pop()
    }
        , {}],
    Tween: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "28890U/NmdCwqWMUik18OnQ", "Tween"),
            Object.defineProperty(o, "__esModule", {
                value: !0
            }),
            o.Ease = o.Tween = void 0;
        var n = t("../timer/timer_mgr")
            , i = t("../util")
            , r = function () {
                function t(t, e, o) {
                    this._target = null,
                        this._useTicks = !1,
                        this.ignoreGlobalPause = !1,
                        this.loop = !1,
                        this.pluginData = null,
                        this._steps = null,
                        this.paused = !1,
                        this.duration = 0,
                        this._prevPos = -1,
                        this.position = null,
                        this._prevPosition = 0,
                        this._stepPosition = 0,
                        this.passive = !1,
                        this.initialize(t, e, o)
                }
                return t.get = function (e, o, n, i) {
                    return void 0 === n && (n = null),
                        void 0 === i && (i = !1),
                        i && t.removeTweens(e),
                        new t(e, o, n)
                }
                    ,
                    t.removeTweens = function (e) {
                        if (e.tween_count) {
                            for (var o = t._tweens, n = o.length - 1; n >= 0; n--)
                                o[n]._target == e && (o[n].paused = !0,
                                    o.splice(n, 1));
                            e.tween_count = 0
                        }
                    }
                    ,
                    t.pauseTweens = function (e) {
                        if (e.tween_count)
                            for (var o = t._tweens, n = o.length - 1; n >= 0; n--)
                                o[n]._target == e && (o[n].paused = !0)
                    }
                    ,
                    t.resumeTweens = function (e) {
                        if (e.tween_count)
                            for (var o = t._tweens, n = o.length - 1; n >= 0; n--)
                                o[n]._target == e && (o[n].paused = !1)
                    }
                    ,
                    t.tick = function (e, o) {
                        void 0 === o && (o = !1);
                        for (var n = t._tweens.concat(), i = n.length - 1; i >= 0; i--) {
                            var r = n[i];
                            o && !r.ignoreGlobalPause || r.paused || r.$tick(r._useTicks ? 1 : e)
                        }
                    }
                    ,
                    t._register = function (e, o) {
                        var r = e._target
                            , s = t._tweens;
                        if (o)
                            r && (r.tween_count = r.tween_count > 0 ? r.tween_count + 1 : 1),
                                s.push(e),
                                t._inited || (t._inited = !0,
                                    n.TimerMgr.getInst().add_updater(i.gen_handler(function (e) {
                                        t.tick(1e3 * e)
                                    })));
                        else {
                            r && r.tween_count--;
                            for (var c = s.length; c--;)
                                if (s[c] == e)
                                    return void s.splice(c, 1)
                        }
                    }
                    ,
                    t.removeAllTweens = function () {
                        for (var e = t._tweens, o = 0, n = e.length; o < n; o++) {
                            var i = e[o];
                            i.paused = !0,
                                i._target.tween_count = 0
                        }
                        e.length = 0
                    }
                    ,
                    t.prototype.initialize = function (e, o, n) {
                        this._target = e,
                            o && (this._useTicks = o.useTicks,
                                this.ignoreGlobalPause = o.ignoreGlobalPause,
                                this.loop = o.loop,
                                this.onChange = o.onChange,
                                this.onChangeObj = o.onChangeObj,
                                o.override && t.removeTweens(e)),
                            this.pluginData = n || {},
                            this._curQueueProps = {},
                            this._initQueueProps = {},
                            this._steps = [],
                            o && o.paused ? this.paused = !0 : t._register(this, !0),
                            o && null != o.position && this.setPosition(o.position, t.NONE)
                    }
                    ,
                    t.prototype.setPosition = function (t, e) {
                        void 0 === e && (e = 1),
                            t < 0 && (t = 0);
                        var o = t
                            , n = !1;
                        if (o >= this.duration)
                            if (this.loop) {
                                var i = o % this.duration;
                                o = o > 0 && 0 === i ? this.duration : i
                            } else
                                o = this.duration,
                                    n = !0;
                        if (o == this._prevPos)
                            return n;
                        n && this.setPaused(!0);
                        var r = this._prevPos;
                        if (this.position = this._prevPos = o,
                            this._prevPosition = t,
                            this._target && this._steps.length > 0) {
                            for (var s = this._steps.length, c = -1, a = 0; a < s && !("step" == this._steps[a].type && (c = a,
                                this._steps[a].t <= o && this._steps[a].t + this._steps[a].d >= o)); a++)
                                ;
                            for (a = 0; a < s; a++)
                                if ("action" == this._steps[a].type)
                                    0 != e && (this._useTicks ? this._runAction(this._steps[a], o, o) : 1 == e && o < r ? (r != this.duration && this._runAction(this._steps[a], r, this.duration),
                                        this._runAction(this._steps[a], 0, o, !0)) : this._runAction(this._steps[a], r, o));
                                else if ("step" == this._steps[a].type && c == a) {
                                    var u = this._steps[c];
                                    this._updateTargetProps(u, Math.min((this._stepPosition = o - u.t) / u.d, 1))
                                }
                        }
                        return this.onChange && this.onChange.call(this.onChangeObj),
                            n
                    }
                    ,
                    t.prototype._runAction = function (t, e, o, n) {
                        void 0 === n && (n = !1);
                        var i = e
                            , r = o;
                        e > o && (i = o,
                            r = e);
                        var s = t.t;
                        (s == r || s > i && s < r || n && s == e) && t.f.apply(t.o, t.p)
                    }
                    ,
                    t.prototype._updateTargetProps = function (e, o) {
                        var n, i, r, s, c, a;
                        if (e || 1 != o) {
                            if (this.passive = !!e.v,
                                this.passive)
                                return;
                            e.e && (o = e.e(o, 0, 1, 1)),
                                n = e.p0,
                                i = e.p1
                        } else
                            this.passive = !1,
                                n = i = this._curQueueProps;
                        for (var u in this._initQueueProps) {
                            null == (s = n[u]) && (n[u] = s = this._initQueueProps[u]),
                                null == (c = i[u]) && (i[u] = c = s),
                                r = s == c || 0 == o || 1 == o || "number" != typeof s ? 1 == o ? c : s : s + (c - s) * o;
                            var l = !1;
                            if (a = t._plugins[u])
                                for (var _ = 0, p = a.length; _ < p; _++) {
                                    var h = a[_].tween(this, u, r, n, i, o, !!e && n == i, !e);
                                    h == t.IGNORE ? l = !0 : r = h
                                }
                            l || (this._target[u] = r)
                        }
                    }
                    ,
                    t.prototype.setPaused = function (e) {
                        return this.paused == e ? this : (this.paused = e,
                            t._register(this, !e),
                            this)
                    }
                    ,
                    t.prototype._cloneProps = function (t) {
                        var e = {};
                        for (var o in t)
                            e[o] = t[o];
                        return e
                    }
                    ,
                    t.prototype._addStep = function (t) {
                        return t.d > 0 && (t.type = "step",
                            this._steps.push(t),
                            t.t = this.duration,
                            this.duration += t.d),
                            this
                    }
                    ,
                    t.prototype._appendQueueProps = function (e) {
                        var o, n, i, r, s;
                        for (var c in e)
                            if (void 0 === this._initQueueProps[c]) {
                                if (n = this._target[c],
                                    o = t._plugins[c])
                                    for (i = 0,
                                        r = o.length; i < r; i++)
                                        n = o[i].init(this, c, n);
                                this._initQueueProps[c] = this._curQueueProps[c] = void 0 === n ? null : n
                            } else
                                n = this._curQueueProps[c];
                        for (var c in e) {
                            if (n = this._curQueueProps[c],
                                o = t._plugins[c])
                                for (s = s || {},
                                    i = 0,
                                    r = o.length; i < r; i++)
                                    o[i].step && o[i].step(this, c, n, e[c], s);
                            this._curQueueProps[c] = e[c]
                        }
                        return s && this._appendQueueProps(s),
                            this._curQueueProps
                    }
                    ,
                    t.prototype._addAction = function (t) {
                        return t.t = this.duration,
                            t.type = "action",
                            this._steps.push(t),
                            this
                    }
                    ,
                    t.prototype._set = function (t, e) {
                        for (var o in t)
                            e[o] = t[o]
                    }
                    ,
                    t.prototype.wait = function (t, e) {
                        if (null == t || t <= 0)
                            return this;
                        var o = this._cloneProps(this._curQueueProps);
                        return this._addStep({
                            d: t,
                            p0: o,
                            p1: o,
                            v: e
                        })
                    }
                    ,
                    t.prototype.to = function (t, e, o) {
                        return void 0 === o && (o = void 0),
                            (isNaN(e) || e < 0) && (e = 0),
                            this._addStep({
                                d: e || 0,
                                p0: this._cloneProps(this._curQueueProps),
                                e: o,
                                p1: this._cloneProps(this._appendQueueProps(t))
                            }),
                            this.set(t)
                    }
                    ,
                    t.prototype.call = function (t, e, o) {
                        return void 0 === e && (e = void 0),
                            void 0 === o && (o = void 0),
                            this._addAction({
                                f: t,
                                p: o || [],
                                o: e || this._target
                            })
                    }
                    ,
                    t.prototype.set = function (t, e) {
                        return void 0 === e && (e = null),
                            this._appendQueueProps(t),
                            this._addAction({
                                f: this._set,
                                o: this,
                                p: [t, e || this._target]
                            })
                    }
                    ,
                    t.prototype.play = function (t) {
                        return t || (t = this),
                            this.call(t.setPaused, t, [!1])
                    }
                    ,
                    t.prototype.pause = function (t) {
                        return t || (t = this),
                            this.call(t.setPaused, t, [!0])
                    }
                    ,
                    t.prototype.$tick = function (t) {
                        this.paused || this.setPosition(this._prevPosition + t)
                    }
                    ,
                    t.NONE = 0,
                    t.LOOP = 1,
                    t.REVERSE = 2,
                    t._tweens = [],
                    t.IGNORE = {},
                    t._plugins = {},
                    t._inited = !1,
                    t._lastTime = 0,
                    t
            }();
        o.Tween = r;
        var s = function () {
            function t() { }
            return t.get = function (t) {
                return t < -1 && (t = -1),
                    t > 1 && (t = 1),
                    function (e) {
                        return 0 == t ? e : t < 0 ? e * (e * -t + 1 + t) : e * ((2 - e) * t + (1 - t))
                    }
            }
                ,
                t.getPowIn = function (t) {
                    return function (e) {
                        return Math.pow(e, t)
                    }
                }
                ,
                t.getPowOut = function (t) {
                    return function (e) {
                        return 1 - Math.pow(1 - e, t)
                    }
                }
                ,
                t.getPowInOut = function (t) {
                    return function (e) {
                        return (e *= 2) < 1 ? .5 * Math.pow(e, t) : 1 - .5 * Math.abs(Math.pow(2 - e, t))
                    }
                }
                ,
                t.sineIn = function (t) {
                    return 1 - Math.cos(t * Math.PI / 2)
                }
                ,
                t.sineOut = function (t) {
                    return Math.sin(t * Math.PI / 2)
                }
                ,
                t.sineInOut = function (t) {
                    return -.5 * (Math.cos(Math.PI * t) - 1)
                }
                ,
                t.getBackIn = function (t) {
                    return function (e) {
                        return e * e * ((t + 1) * e - t)
                    }
                }
                ,
                t.getBackOut = function (t) {
                    return function (e) {
                        return --e * e * ((t + 1) * e + t) + 1
                    }
                }
                ,
                t.getBackInOut = function (t) {
                    return t *= 1.525,
                        function (e) {
                            return (e *= 2) < 1 ? e * e * ((t + 1) * e - t) * .5 : .5 * ((e -= 2) * e * ((t + 1) * e + t) + 2)
                        }
                }
                ,
                t.circIn = function (t) {
                    return -(Math.sqrt(1 - t * t) - 1)
                }
                ,
                t.circOut = function (t) {
                    return Math.sqrt(1 - --t * t)
                }
                ,
                t.circInOut = function (t) {
                    return (t *= 2) < 1 ? -.5 * (Math.sqrt(1 - t * t) - 1) : .5 * (Math.sqrt(1 - (t -= 2) * t) + 1)
                }
                ,
                t.bounceIn = function (e) {
                    return 1 - t.bounceOut(1 - e)
                }
                ,
                t.bounceOut = function (t) {
                    return t < 1 / 2.75 ? 7.5625 * t * t : t < 2 / 2.75 ? 7.5625 * (t -= 1.5 / 2.75) * t + .75 : t < 2.5 / 2.75 ? 7.5625 * (t -= 2.25 / 2.75) * t + .9375 : 7.5625 * (t -= 2.625 / 2.75) * t + .984375
                }
                ,
                t.bounceInOut = function (e) {
                    return e < .5 ? .5 * t.bounceIn(2 * e) : .5 * t.bounceOut(2 * e - 1) + .5
                }
                ,
                t.getElasticIn = function (t, e) {
                    var o = 2 * Math.PI;
                    return function (n) {
                        if (0 == n || 1 == n)
                            return n;
                        var i = e / o * Math.asin(1 / t);
                        return -t * Math.pow(2, 10 * (n -= 1)) * Math.sin((n - i) * o / e)
                    }
                }
                ,
                t.getElasticOut = function (t, e) {
                    var o = 2 * Math.PI;
                    return function (n) {
                        if (0 == n || 1 == n)
                            return n;
                        var i = e / o * Math.asin(1 / t);
                        return t * Math.pow(2, -10 * n) * Math.sin((n - i) * o / e) + 1
                    }
                }
                ,
                t.getElasticInOut = function (t, e) {
                    var o = 2 * Math.PI;
                    return function (n) {
                        var i = e / o * Math.asin(1 / t);
                        return (n *= 2) < 1 ? t * Math.pow(2, 10 * (n -= 1)) * Math.sin((n - i) * o / e) * -.5 : t * Math.pow(2, -10 * (n -= 1)) * Math.sin((n - i) * o / e) * .5 + 1
                    }
                }
                ,
                t.quadIn = t.getPowIn(2),
                t.quadOut = t.getPowOut(2),
                t.quadInOut = t.getPowInOut(2),
                t.cubicIn = t.getPowIn(3),
                t.cubicOut = t.getPowOut(3),
                t.cubicInOut = t.getPowInOut(3),
                t.quartIn = t.getPowIn(4),
                t.quartOut = t.getPowOut(4),
                t.quartInOut = t.getPowInOut(4),
                t.quintIn = t.getPowIn(5),
                t.quintOut = t.getPowOut(5),
                t.quintInOut = t.getPowInOut(5),
                t.backIn = t.getBackIn(1.7),
                t.backOut = t.getBackOut(1.7),
                t.backInOut = t.getBackInOut(1.7),
                t.elasticIn = t.getElasticIn(1, .3),
                t.elasticOut = t.getElasticOut(1, .3),
                t.elasticInOut = t.getElasticInOut(1, .3 * 1.5),
                t
        }();
        o.Ease = s,
            cc._RF.pop()
    }
        , {
        "../timer/timer_mgr": "timer_mgr",
        "../util": "util"
    }],
    instruction: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "94435DNUyVKnYGtcpWwgeo2", "instruction");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        ), r = this && this.__decorate || function (t, e, o, n) {
            var i, r = arguments.length, s = r < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                s = Reflect.decorate(t, e, o, n);
            else
                for (var c = t.length - 1; c >= 0; c--)
                    (i = t[c]) && (s = (r < 3 ? i(s) : r > 3 ? i(e, o, s) : i(e, o)) || s);
            return r > 3 && s && Object.defineProperty(e, o, s),
                s
        }
            ;
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var s = t("../../common/ui/pop_ui_base")
            , c = t("../../common/ui/pop_mgr")
            , a = t("../../common/audio/AudioPlayer")
            , u = t("../../common/event/EventDispatch")
            , l = cc._decorator
            , _ = l.ccclass
            , p = l.property
            , h = function (t) {
                function e() {
                    var e = null !== t && t.apply(this, arguments) || this;
                    return e.bg = null,
                        e.node_top = null,
                        e.btn_play = null,
                        e.guide_hand = null,
                        e.hand = null,
                        e
                }
                return i(e, t),
                    e.prototype.onLoad = function () {
                        this.btn_play.on(cc.Node.EventType.TOUCH_START, this.playGame, this),
                            this.btn_play.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this),
                            this.hand.runAction(cc.repeatForever(cc.sequence(cc.moveBy(.5, 400, 0), cc.moveBy(.5, -400, 0), cc.moveBy(.5, -350, 0), cc.moveBy(.5, 350, 0))))
                    }
                    ,
                    e.prototype.playGame = function () {
                        c.pop_mgr.get_inst().show(c.UI_CONFIG.game),
                            a.AudioPlayer.ins().play_sound(a.AUDIO_CONFIG.Audio_Btn)
                    }
                    ,
                    e.prototype.onTouchMove = function (t) {
                        u.EventDispatch.ins().fire(u.Event_Name.GAME_ON_TOUCH_MOVE, t)
                    }
                    ,
                    r([p(cc.Node)], e.prototype, "bg", void 0),
                    r([p(cc.Node)], e.prototype, "node_top", void 0),
                    r([p(cc.Node)], e.prototype, "btn_play", void 0),
                    r([p(cc.Node)], e.prototype, "guide_hand", void 0),
                    r([p(cc.Node)], e.prototype, "hand", void 0),
                    r([_], e)
            }(s.POP_UI_BASE);
        o.default = h,
            cc._RF.pop()
    }
        , {
        "../../common/audio/AudioPlayer": "AudioPlayer",
        "../../common/event/EventDispatch": "EventDispatch",
        "../../common/ui/pop_mgr": "pop_mgr",
        "../../common/ui/pop_ui_base": "pop_ui_base"
    }],
    linklist: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "bdd09bYpc5GwI0jOASAzWlq", "linklist"),
            Object.defineProperty(o, "__esModule", {
                value: !0
            }),
            o.LinkList = void 0;
        var n = function () {
            function t() {
                this._head = this._tail = null,
                    this.pool = []
            }
            return t.prototype.spawn_node = function (t, e) {
                var o = this.pool.pop();
                return o ? (o.key = t,
                    o.data = e,
                    o.next = null) : o = {
                        key: t,
                        data: e,
                        next: null
                    },
                    o
            }
                ,
                Object.defineProperty(t.prototype, "head", {
                    get: function () {
                        return this._head
                    },
                    enumerable: !1,
                    configurable: !0
                }),
                Object.defineProperty(t.prototype, "tail", {
                    get: function () {
                        return this._tail
                    },
                    enumerable: !1,
                    configurable: !0
                }),
                t.prototype.append = function (t, e) {
                    var o = this.spawn_node(t, e);
                    return this._tail ? (this._tail.next = o,
                        this._tail = o) : this._head = this._tail = o,
                        o.key
                }
                ,
                t.prototype.remove = function (t) {
                    if (!t)
                        return null;
                    if (!this._head)
                        return null;
                    for (var e, o = this._head; o && o.key != t;)
                        e = o,
                            o = o.next;
                    return o ? (e ? (e.next = o.next,
                        o.next || (this._tail = e)) : (this._head = o.next,
                            o.next || (this._tail = null)),
                        this.pool.push(o),
                        o) : null
                }
                ,
                t
        }();
        o.LinkList = n,
            cc._RF.pop()
    }
        , {}],
    loader_mgr1: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "67de1EVe7JM754Ys4EB94Vw", "loader_mgr1"),
            o.__esModule = !0,
            o.loader_mgr = void 0;
        var n = function () {
            function t() { }
            return t.get_inst = function () {
                return t.inst || (t.inst = new t),
                    t.inst
            }
                ,
                t.prototype.loadExternalAsset = function (t, e, o) {
                    var n = cc.loader.getRes(t);
                    n ? e.exec(n) : cc.loader.load(o ? {
                        url: t,
                        type: o
                    } : t, function (o, n) {
                        o ? cc.warn("loadExternalAsset error", t) : e.exec(n)
                    })
                }
                ,
                t.prototype.loadExternalAssets = function (t, e, o) {
                    var n = {}
                        , i = [];
                    if (t.forEach(function (t) {
                        var e = cc.loader.getRes(t);
                        e ? n[t] = e : i.push(t)
                    }),
                        0 != i.length) {
                        var r = [];
                        i.forEach(function (t, e) {
                            o ? r.push({
                                url: t,
                                type: o[e]
                            }) : r.push(t)
                        }),
                            cc.loader.load(r, function (t, o) {
                                cc.log("loadExternalAssets from remote url"),
                                    t ? cc.warn("loadExternalAssets error", t) : (i.forEach(function (t) {
                                        n[t] = o.getContent(t)
                                    }),
                                        e.exec(n))
                            })
                    } else
                        e.exec(n)
                }
                ,
                t.prototype.loadRawAsset = function (t, e) {
                    var o = cc.loader.getRes(t);
                    o ? e.exec(o) : cc.loader.loadRes(t, function (o, n) {
                        o ? cc.warn("loadRawAsset error", t) : e.exec(n)
                    })
                }
                ,
                t.prototype.loadAsset = function (t, e, o) {
                    var n = cc.loader.getRes(t, o);
                    n ? e.exec(n) : cc.loader.loadRes(t, o, function (o, n) {
                        o ? cc.warn("loadAsset error", t) : e.exec(n)
                    })
                }
                ,
                t.prototype.loadResArray = function (t, e) {
                    var o = {}
                        , n = [];
                    t.forEach(function (t) {
                        var e = cc.loader.getRes(t);
                        e ? o[t] = e : n.push(t)
                    }),
                        0 != n.length ? cc.loader.loadResArray(n, function (t) {
                            t ? cc.warn("loadResArray error", n) : (n.forEach(function (t) {
                                o[t] = cc.loader.getRes(t)
                            }),
                                e.exec(o))
                        }) : e.exec(o)
                }
                ,
                t.prototype.loadPrefabObj = function (t, e) {
                    var o = cc.loader.getRes(t, cc.Prefab);
                    if (o) {
                        var n = cc.instantiate(o);
                        e.exec(n)
                    } else
                        cc.loader.loadRes(t, cc.Prefab, function (o, n) {
                            if (o)
                                cc.warn("loadPrefabObj error", t, o);
                            else {
                                var i = cc.instantiate(n);
                                e.exec(i)
                            }
                        })
                }
                ,
                t.prototype.loadPrefabObjArray = function (t, e) {
                    var o = {}
                        , n = [];
                    t.forEach(function (t) {
                        var e = cc.loader.getRes(t, cc.Prefab);
                        e ? o[t] = cc.instantiate(e) : n.push(t)
                    }),
                        0 != n.length ? cc.loader.loadResArray(n, cc.Prefab, function (t) {
                            t ? cc.warn("loadPrefabObjArray error", n) : (n.forEach(function (t) {
                                o[t] = cc.instantiate(cc.loader.getRes(t, cc.Prefab))
                            }),
                                e.exec(o))
                        }) : e.exec(o)
                }
                ,
                t.prototype.loadPrefabDir = function (t, e) {
                    var o = {};
                    cc.loader.loadResDir(t, cc.Prefab, function (n, i, r) {
                        n ? cc.warn("loadPrefabObjDir error", t) : (r.forEach(function (t) {
                            o[t] = cc.loader.getRes(t, cc.Prefab)
                        }),
                            e.exec(o))
                    })
                }
                ,
                t.prototype.loadPrefabObjDir = function (t, e) {
                    var o = {};
                    cc.loader.loadResDir(t, cc.Prefab, function (n, i, r) {
                        n ? cc.warn("loadPrefabObjDir error", t) : (r.forEach(function (t) {
                            o[t] = cc.instantiate(cc.loader.getRes(t, cc.Prefab))
                        }),
                            e.exec(o))
                    })
                }
                ,
                t.prototype.release = function (t) {
                    t instanceof cc.Node ? t.destroy() : cc.loader.release(t)
                }
                ,
                t
        }();
        o.loader_mgr = n,
            cc._RF.pop()
    }
        , {}],
    loader_mgr: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "ef581f23+RGqbKbSbfR960u", "loader_mgr"),
            Object.defineProperty(o, "__esModule", {
                value: !0
            }),
            o.loader_mgr = void 0;
        var n = function () {
            function t() { }
            return t.get_inst = function () {
                return t.inst || (t.inst = new t),
                    t.inst
            }
                ,
                t.prototype.loadExternalAsset = function (t, e, o) {
                    var n = cc.loader.getRes(t);
                    n ? e.exec(n) : cc.loader.load(o ? {
                        url: t,
                        type: o
                    } : t, function (o, n) {
                        o ? cc.warn("loadExternalAsset error", t) : e.exec(n)
                    })
                }
                ,
                t.prototype.loadExternalAssets = function (t, e, o) {
                    var n = {}
                        , i = [];
                    if (t.forEach(function (t) {
                        var e = cc.loader.getRes(t);
                        e ? n[t] = e : i.push(t)
                    }),
                        0 != i.length) {
                        var r = [];
                        i.forEach(function (t, e) {
                            o ? r.push({
                                url: t,
                                type: o[e]
                            }) : r.push(t)
                        }),
                            cc.loader.load(r, function (t, o) {
                                cc.log("loadExternalAssets from remote url"),
                                    t ? cc.warn("loadExternalAssets error", t) : (i.forEach(function (t) {
                                        n[t] = o.getContent(t)
                                    }),
                                        e.exec(n))
                            })
                    } else
                        e.exec(n)
                }
                ,
                t.prototype.loadRawAsset = function (t, e) {
                    var o = cc.loader.getRes(t);
                    o ? e.exec(o) : cc.loader.loadRes(t, function (o, n) {
                        o ? cc.warn("loadRawAsset error", t) : e.exec(n)
                    })
                }
                ,
                t.prototype.loadAsset = function (t, e, o) {
                    var n = cc.loader.getRes(t, o);
                    n ? e.exec(n) : cc.loader.loadRes(t, o, function (o, n) {
                        o ? cc.warn("loadAsset error", t) : e.exec(n)
                    })
                }
                ,
                t.prototype.loadResArray = function (t, e) {
                    var o = {}
                        , n = [];
                    t.forEach(function (t) {
                        var e = cc.loader.getRes(t);
                        e ? o[t] = e : n.push(t)
                    }),
                        0 != n.length ? cc.loader.loadResArray(n, function (t) {
                            t ? cc.warn("loadResArray error", n) : (n.forEach(function (t) {
                                o[t] = cc.loader.getRes(t)
                            }),
                                e.exec(o))
                        }) : e.exec(o)
                }
                ,
                t.prototype.loadPrefabObj = function (t, e) {
                    var o = cc.loader.getRes(t, cc.Prefab);
                    if (o) {
                        var n = cc.instantiate(o);
                        e.exec(n)
                    } else
                        cc.loader.loadRes(t, cc.Prefab, function (o, n) {
                            if (o)
                                cc.warn("loadPrefabObj error", t, o);
                            else {
                                var i = cc.instantiate(n);
                                e.exec(i)
                            }
                        })
                }
                ,
                t.prototype.loadPrefabObjArray = function (t, e) {
                    var o = {}
                        , n = [];
                    t.forEach(function (t) {
                        var e = cc.loader.getRes(t, cc.Prefab);
                        e ? o[t] = cc.instantiate(e) : n.push(t)
                    }),
                        0 != n.length ? cc.loader.loadResArray(n, cc.Prefab, function (t) {
                            t ? cc.warn("loadPrefabObjArray error", n) : (n.forEach(function (t) {
                                o[t] = cc.instantiate(cc.loader.getRes(t, cc.Prefab))
                            }),
                                e.exec(o))
                        }) : e.exec(o)
                }
                ,
                t.prototype.loadPrefabDir = function (t, e) {
                    var o = {};
                    cc.loader.loadResDir(t, cc.Prefab, function (n, i, r) {
                        n ? cc.warn("loadPrefabObjDir error", t) : (r.forEach(function (t) {
                            o[t] = cc.loader.getRes(t, cc.Prefab)
                        }),
                            e.exec(o))
                    })
                }
                ,
                t.prototype.loadPrefabObjDir = function (t, e) {
                    var o = {};
                    cc.loader.loadResDir(t, cc.Prefab, function (n, i, r) {
                        n ? cc.warn("loadPrefabObjDir error", t) : (r.forEach(function (t) {
                            o[t] = cc.instantiate(cc.loader.getRes(t, cc.Prefab))
                        }),
                            e.exec(o))
                    })
                }
                ,
                t.prototype.release = function (t) {
                    t instanceof cc.Node ? t.destroy() : cc.loader.release(t)
                }
                ,
                t
        }();
        o.loader_mgr = n,
            cc._RF.pop()
    }
        , {}],
    pool_mgr: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "29eb514/fREDJnvpZLCUcBZ", "pool_mgr"),
            Object.defineProperty(o, "__esModule", {
                value: !0
            }),
            o.pool_mgr = void 0;
        var n = t("../loader/loader_mgr")
            , i = t("./ui_pool")
            , r = function () {
                function t() {
                    this.ui_pool = new i.ui_pool
                }
                return t.get_inst = function () {
                    return this._inst || (this._inst = new t),
                        this._inst
                }
                    ,
                    t.prototype.get_ui = function (t, e) {
                        var o = this.ui_pool.get(t);
                        o ? e.exec(o) : n.loader_mgr.get_inst().loadPrefabObj(t, e)
                    }
                    ,
                    t.prototype.put_ui = function (t, e) {
                        e ? this.ui_pool.put(t, e) : cc.warn("pool_mgr:put_ui, invalid node")
                    }
                    ,
                    t.prototype.clear_atpath = function (t) {
                        this.ui_pool.clear_atpath(t)
                    }
                    ,
                    t.prototype.clear = function () {
                        this.ui_pool.clear()
                    }
                    ,
                    t.prototype.dump = function () {
                        this.ui_pool.dump()
                    }
                    ,
                    t
            }();
        o.pool_mgr = r,
            cc._RF.pop()
    }
        , {
        "../loader/loader_mgr": "loader_mgr",
        "./ui_pool": "ui_pool"
    }],
    pop_mgr: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "424697+0GpMebIfgAZGNA0h", "pop_mgr"),
            Object.defineProperty(o, "__esModule", {
                value: !0
            }),
            o.UI_TRANSITION_TYPE = o.UI_CONFIG = o.pop_mgr = void 0;
        var n, i = t("../pool/pool_mgr"), r = t("../util"), s = t("./pop_ui_base"), c = t("../timer/timer_mgr"), a = t("../util"), u = t("../tween/Tween"), l = function () {
            function t() {
                this.ui_cache = {},
                    this.ui_stack = new Array
            }
            return t.get_inst = function () {
                return this.inst || (this.inst = new t),
                    this.inst
            }
                ,
                t.prototype.get_ui = function (t) {
                    var e = this.ui_cache[t];
                    return e || (this.ui_cache[t] = e = {
                        node: null,
                        is_show: !1
                    }),
                        e
                }
                ,
                t.prototype.clear = function () {
                    for (var t in this.ui_cache)
                        this.hide(t);
                    this.ui_cache = {},
                        this.ui_stack.length = 0
                }
                ,
                t.prototype.peek = function () {
                    return this.ui_stack[this.ui_stack.length - 1]
                }
                ,
                t.prototype.set_handlers = function (t, e) {
                    this.ui_show_handler = t,
                        this.ui_hide_handler = e
                }
                ,
                t.prototype.is_show = function (t) {
                    return null != this.ui_cache[t]
                }
                ,
                t.prototype.show = function (t, e) {
                    for (var o = this, n = [], u = 2; u < arguments.length; u++)
                        n[u - 2] = arguments[u];
                    var l = this.get_ui(t);
                    l.is_show || (l.is_show = !0,
                        i.pool_mgr.get_inst().get_ui(t, r.gen_handler(function (r) {
                            l.is_show ? (l.node = r,
                                o.applyTransitionEffect(r, e),
                                cc.director.getScene().getChildByName("Canvas").getChildByName("mid_layer").addChild(r),
                                c.TimerMgr.getInst().once(0, a.gen_handler(function () {
                                    if (l.is_show) {
                                        var e = r.getComponent(s.POP_UI_BASE);
                                        e.ui_name = t,
                                            e.__show__.apply(e, n),
                                            o.ui_stack.push(t),
                                            o.ui_show_handler && o.ui_show_handler.exec()
                                    }
                                }))) : i.pool_mgr.get_inst().put_ui(t, r)
                        }, this)))
                }
                ,
                t.prototype.hide = function (t) {
                    var e = this.ui_cache[t];
                    if (e && (this.ui_cache[t] = null,
                        e.is_show = !1,
                        e.node)) {
                        i.pool_mgr.get_inst().put_ui(t, e.node),
                            e.node.getComponent(s.POP_UI_BASE).__hide__();
                        var o = this.ui_stack.lastIndexOf(t);
                        -1 != o && this.ui_stack.splice(o, 1),
                            this.ui_hide_handler && this.ui_hide_handler.exec()
                    }
                }
                ,
                t.prototype.applyTransitionEffect = function (t, e) {
                    if (!e || e.transType != n.None)
                        switch ((e = e || {
                            transType: n.FadeIn,
                            duration: 500
                        }).transType) {
                            case n.FadeIn:
                                u.Tween.removeTweens(t),
                                    t.opacity = 0,
                                    u.Tween.get(t).to({
                                        opacity: 255
                                    }, e.duration)
                        }
                }
                ,
                t
        }();
        o.pop_mgr = l,
            o.UI_CONFIG = {
                overlay_bg: "prefab/panels/panel_overlay_bg",
                game: "prefab/view/game",
                upgrade: "prefab/view/upgrade",
                rank: "prefab/view/rank",
                customize: "prefab/view/customize",
                instruction: "prefab/view/instruction",
                result: "prefab/view/result",
                menu: "prefab/view/menu",
                loading: "prefab/view/loading"
            },
            function (t) {
                t[t.None = 1] = "None",
                    t[t.FadeIn = 2] = "FadeIn",
                    t[t.DropDown = 3] = "DropDown",
                    t[t.PopUp = 4] = "PopUp",
                    t[t.LeftIn = 5] = "LeftIn",
                    t[t.RightIn = 6] = "RightIn"
            }(n = o.UI_TRANSITION_TYPE || (o.UI_TRANSITION_TYPE = {})),
            cc._RF.pop()
    }
        , {
        "../pool/pool_mgr": "pool_mgr",
        "../timer/timer_mgr": "timer_mgr",
        "../tween/Tween": "Tween",
        "../util": "util",
        "./pop_ui_base": "pop_ui_base"
    }],
    pop_ui_base: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "e2e68FLOYBOaqRk0bNgNIyc", "pop_ui_base");
        var n, i = this && this.__extends || (n = function (t, e) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function (t, e) {
                t.__proto__ = e
            }
                || function (t, e) {
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
            )(t, e)
        }
            ,
            function (t, e) {
                function o() {
                    this.constructor = t
                }
                n(t, e),
                    t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype,
                        new o)
            }
        ), r = this && this.__decorate || function (t, e, o, n) {
            var i, r = arguments.length, s = r < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                s = Reflect.decorate(t, e, o, n);
            else
                for (var c = t.length - 1; c >= 0; c--)
                    (i = t[c]) && (s = (r < 3 ? i(s) : r > 3 ? i(e, o, s) : i(e, o)) || s);
            return r > 3 && s && Object.defineProperty(e, o, s),
                s
        }
            ;
        Object.defineProperty(o, "__esModule", {
            value: !0
        }),
            o.POP_UI_BASE = void 0;
        var s = t("./pop_mgr")
            , c = t("../pool/pool_mgr")
            , a = t("../util")
            , u = t("../../common/audio/AudioPlayer")
            , l = cc._decorator
            , _ = l.ccclass
            , p = l.property
            , h = function (t) {
                function e() {
                    var e = null !== t && t.apply(this, arguments) || this;
                    return e.btn_close = null,
                        e
                }
                return i(e, t),
                    Object.defineProperty(e.prototype, "ui_name", {
                        set: function (t) {
                            this._ui_name = t
                        },
                        enumerable: !1,
                        configurable: !0
                    }),
                    e.prototype.__show__ = function () {
                        for (var t = this, e = [], o = 0; o < arguments.length; o++)
                            e[o] = arguments[o];
                        this.btn_close && this.btn_close.node.on(cc.Node.EventType.TOUCH_END, this.onCloseBtnTouch, this),
                            this.is_show = !0,
                            this.on_show.apply(this, e);
                        var n = this.node.getChildByName("panel_overlay_bg");
                        n || c.pool_mgr.get_inst().get_ui(s.UI_CONFIG.overlay_bg, a.gen_handler(function (e) {
                            t.is_show && !t.node.getChildByName("panel_overlay_bg") ? (e.name = "panel_overlay_bg",
                                t.node.addChild(e),
                                e.setSiblingIndex(0)) : c.pool_mgr.get_inst().put_ui(s.UI_CONFIG.overlay_bg, e)
                        }, this))
                    }
                    ,
                    e.prototype.__hide__ = function () {
                        cc.log("hide", this._ui_name),
                            this.btn_close && this.btn_close.node.off(cc.Node.EventType.TOUCH_END, this.onCloseBtnTouch, this),
                            this.is_show = !1,
                            this.on_hide()
                    }
                    ,
                    e.prototype.on_show = function () {
                        for (var t = [], e = 0; e < arguments.length; e++)
                            t[e] = arguments[e]
                    }
                    ,
                    e.prototype.on_hide = function () { }
                    ,
                    e.prototype.hide = function () {
                        s.pop_mgr.get_inst().hide(this._ui_name)
                    }
                    ,
                    e.prototype.onCloseBtnTouch = function () {
                        this.hide(),
                            u.AudioPlayer.ins().play_sound(u.AUDIO_CONFIG.Audio_Btn)
                        // wop.trigger("inter",{
                        //     callback:()=>{

                        //     }
                        // })
                    }
                    ,
                    r([p(cc.Button)], e.prototype, "btn_close", void 0),
                    r([_], e)
            }(cc.Component);
        o.POP_UI_BASE = h,
            cc._RF.pop()
    }
        , {
        "../../common/audio/AudioPlayer": "AudioPlayer",
        "../pool/pool_mgr": "pool_mgr",
        "../util": "util",
        "./pop_mgr": "pop_mgr"
    }],
    timer_mgr: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "55db98KfNxEboJhHMMpseOV", "timer_mgr"),
            Object.defineProperty(o, "__esModule", {
                value: !0
            }),
            o.TimerMgr = void 0;
        var n = t("../linklist")
            , i = function () {
                function t() {
                    this.key = 0,
                        this.pool = [],
                        this.iterList = new n.LinkList,
                        this.pendingList = new n.LinkList
                }
                return t.getInst = function () {
                    return this.inst || (this.inst = new t),
                        this.inst
                }
                    ,
                    t.prototype.add = function (t, e, o, n, i) {
                        void 0 === i && (i = !1);
                        var r = this.pool.pop();
                        return r ? (r.interval = t,
                            r.delay = e,
                            r.repeat = o,
                            r.elapsed = 0,
                            r.times = 0,
                            r.is_updater = i,
                            r.cb = n) : r = {
                                interval: t,
                                delay: e,
                                repeat: o,
                                elapsed: 0,
                                times: 0,
                                is_updater: i,
                                cb: n
                            },
                            this.pendingList.append(++this.key, r)
                    }
                    ,
                    t.prototype.remove = function (t) {
                        this.removeIter(t) || this.removePending(t)
                    }
                    ,
                    t.prototype.removeIter = function (t) {
                        var e = this.iterList.remove(t);
                        return !!e && (this.pool.push(e.data),
                            !0)
                    }
                    ,
                    t.prototype.removePending = function (t) {
                        var e = this.pendingList.remove(t);
                        return !!e && (this.pool.push(e.data),
                            !0)
                    }
                    ,
                    t.prototype.loop = function (t, e) {
                        return this.add(t, 0, 0, e)
                    }
                    ,
                    t.prototype.loopTimes = function (t, e, o) {
                        return this.add(t, 0, e, o)
                    }
                    ,
                    t.prototype.frameLoop = function (t) {
                        return this.add(1 / 24, 0, 0, t)
                    }
                    ,
                    t.prototype.delayLoop = function (t, e, o) {
                        return this.add(t, e, 0, o)
                    }
                    ,
                    t.prototype.once = function (t, e) {
                        return this.add(0, t, 1, e)
                    }
                    ,
                    t.prototype.add_updater = function (t) {
                        return this.add(0, 0, 0, t, !0)
                    }
                    ,
                    t.prototype.update = function (t) {
                        for (var e = this.iterList.head; e;)
                            if (e.data.is_updater) {
                                var o = e.next;
                                e.data.cb.exec(t),
                                    e = o
                            } else
                                0 != e.data.repeat && e.data.times >= e.data.repeat ? (o = e.next,
                                    this.removeIter(e.key),
                                    e = o) : e.data.elapsed >= e.data.delay + e.data.interval ? (o = e.next,
                                        e.data.times++,
                                        e.data.elapsed = e.data.delay,
                                        e.data.cb.exec(),
                                        e = o) : (e.data.elapsed += t,
                                            e = e.next);
                        for (e = this.pendingList.head; e;) {
                            var n = e.key
                                , i = e.data;
                            e = e.next,
                                this.pendingList.remove(n),
                                this.iterList.append(n, i)
                        }
                    }
                    ,
                    t
            }();
        o.TimerMgr = i,
            cc._RF.pop()
    }
        , {
        "../linklist": "linklist"
    }],
    ui_pool: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "0a950yUsOZNy5HTWZ9gz1hi", "ui_pool"),
            Object.defineProperty(o, "__esModule", {
                value: !0
            }),
            o.ui_pool = void 0;
        var n = function () {
            function t() {
                this.max_size = 2,
                    this.cache = {},
                    this.path2time = {},
                    this.size = 0
            }
            return t.prototype.get = function (t) {
                var e = this.cache[t];
                return e && e.length > 0 ? (this.size--,
                    e.pop()) : null
            }
                ,
                t.prototype.put = function (t, e) {
                    if (this.size >= this.max_size) {
                        var o = void 0
                            , n = cc.sys.now();
                        for (var i in this.cache)
                            this.cache[i].length > 0 && this.path2time[i] < n && (n = this.path2time[i],
                                o = i);
                        o && "" != o && (this.cache[o].pop().destroy(),
                            this.size--)
                    }
                    var r = this.cache[t];
                    r || (this.cache[t] = r = []),
                        e.removeFromParent(!1),
                        r.push(e),
                        this.size++,
                        this.path2time[t] = cc.sys.now()
                }
                ,
                t.prototype.clear_atpath = function (t) {
                    var e = this.cache[t];
                    if (e && !(e.length <= 0))
                        for (; e.length > 0;)
                            e.pop().destroy(),
                                this.size--
                }
                ,
                t.prototype.clear = function () {
                    for (var t in this.cache)
                        this.clear_atpath(t);
                    this.cache = {},
                        this.path2time = {},
                        0 != this.size && cc.warn("size should be 0, but now is", this.size)
                }
                ,
                t.prototype.dump = function () {
                    var t = "********ui_pool dump********";
                    for (var e in this.cache)
                        t += "\n" + e + "\n",
                            this.cache[e].forEach(function (e) {
                                t += e.name + ","
                            });
                    cc.log(t)
                }
                ,
                t
        }();
        o.ui_pool = n,
            cc._RF.pop()
    }
        , {}],
    use_reversed_rotateTo: [function (t, e) {
        "use strict";
        cc._RF.push(e, "f89130WKq1Kp663GvrvKu66", "use_reversed_rotateTo"),
            cc.RotateTo._reverse = !0,
            cc._RF.pop()
    }
        , {}],
    util: [function (t, e, o) {
        "use strict";
        cc._RF.push(e, "5e6fdXDEbdM/owIk62/j/0P", "util");
        var n = this && this.__spreadArrays || function () {
            for (var t = 0, e = 0, o = arguments.length; e < o; e++)
                t += arguments[e].length;
            var n = Array(t)
                , i = 0;
            for (e = 0; e < o; e++)
                for (var r = arguments[e], s = 0, c = r.length; s < c; s++,
                    i++)
                    n[i] = r[s];
            return n
        }
            ;
        Object.defineProperty(o, "__esModule", {
            value: !0
        }),
            o.destroyBreathAction = o.createBreathAction = o.extend = o.strfmt = o.load_external_img = o.load_plist_img = o.load_img = o.gen_handler = o.handler = void 0;
        var i = t("../common/loader/loader_mgr")
            , r = []
            , s = function () {
                function t() { }
                return t.prototype.init = function (t, e) {
                    void 0 === e && (e = null);
                    for (var o = [], n = 2; n < arguments.length; n++)
                        o[n - 2] = arguments[n];
                    this.cb = t,
                        this.host = e,
                        this.args = o
                }
                    ,
                    t.prototype.exec = function () {
                        for (var t = [], e = 0; e < arguments.length; e++)
                            t[e] = arguments[e];
                        this.cb.apply(this.host, this.args.concat(t))
                    }
                    ,
                    t
            }();
        function c(t, e) {
            void 0 === e && (e = null);
            for (var o = [], i = 2; i < arguments.length; i++)
                o[i - 2] = arguments[i];
            var c = r.length < 0 ? r.pop() : new s;
            return c.init.apply(c, n([t, e], o)),
                c
        }
        o.handler = s,
            o.gen_handler = c,
            o.load_img = function (t, e) {
                i.loader_mgr.get_inst().loadAsset(e, c(function (e) {
                    t.spriteFrame = e
                }), cc.SpriteFrame)
            }
            ,
            o.load_plist_img = function (t, e, o) {
                i.loader_mgr.get_inst().loadAsset(e, c(function (n) {
                    var i = n.getSpriteFrame(o);
                    i ? t.spriteFrame = i : cc.warn("path error (" + e + " " + o + ")")
                }), cc.SpriteAtlas)
            }
            ;
        var a = {};
        o.load_external_img = function (t, e, o) {
            a[e] ? t.spriteFrame = a[e] : (t.node.active = !1,
                i.loader_mgr.get_inst().loadExternalAsset(e, c(function (o) {
                    a[e] = new cc.SpriteFrame(o),
                        t.node && (t.node.active = !0,
                            t.spriteFrame = a[e])
                }), o))
        }
            ,
            o.strfmt = function (t) {
                for (var e = [], o = 1; o < arguments.length; o++)
                    e[o - 1] = arguments[o];
                return t.replace(/\{(\d+)\}/g, function (t, o) {
                    return e[o] || t
                })
            }
            ,
            o.extend = function (t) {
                for (var e = [], o = 1; o < arguments.length; o++)
                    e[o - 1] = arguments[o];
                for (var n = 0; n < e.length; n += 1) {
                    var i = e[n];
                    for (var r in i)
                        i.hasOwnProperty(r) && (t[r] = i[r])
                }
                return t
            }
            ,
            o.createBreathAction = function (t) {
                var e = cc.repeatForever(cc.sequence(cc.scaleTo(.6, 1.1), cc.scaleTo(.6, .9)));
                t.runAction(e)
            }
            ,
            o.destroyBreathAction = function (t) {
                t.stopAllActions()
            }
            ,
            cc._RF.pop()
    }
        , {
        "../common/loader/loader_mgr": "loader_mgr"
    }]
}, {}, ["use_reversed_rotateTo", "AudioPlayer", "SingletonClass", "EventDispatch", "linklist", "loader_mgr1", "loader_mgr", "LocalStorage", "pool_mgr", "ui_pool", "RandomUtil", "timer_mgr", "Tween", "pop_mgr", "pop_ui_base", "util", "GameConst", "Main", "CommonLabelScroll", "BallItem", "BrickItem", "GameModel", "GameView", "MenuView", "ResultView", "instruction"]);
