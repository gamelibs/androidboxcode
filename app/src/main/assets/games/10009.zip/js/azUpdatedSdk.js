let azAdWrapper;
const sgSdk = function() {
    let e, a = !1, n = !1;
    function t(e) {
        "pagehide" === e.type || "blur" === e.type ? window.game.onBlur.dispatch(e) : "pageshow" !== e.type && "focus" !== e.type || window.game.onFocus.dispatch(e)
    }
    function d() {
        window.game.time.gamePaused(),
        window.game.sound.setMute()
    }
    function o() {
        window.game.input.reset(),
        window.game.time.gameResumed(),
        window.game.sound.unsetMute()
    }
    function s() {
        window.game.onPause.dispatch()
    }
    function r() {
        !0 === n && window.game.onResume.dispatch()
    }
    function i() {
        n = !1,
        s()
    }
    function c() {
        n = !0,
        !1 === a && r()
    }
    function l() {
        !function() {
            let e = document.getElementById("loader");
            e && (e.style.display = "block")
        }(),
        a = !0
    }
    function g(e, a) {
        l(),
        azAdWrapper.once(h5ads.AdEvents.CONTENT_RESUMED, (()=>{
            e.callback.call(a)
        }
        )),
        azAdWrapper.showAd(h5ads.AdType.interstitial)
    }
    return {
        initialize: function(a, n, t) {
            e = n;
            const d = {
                config: {
                    rewarded: {
                        enabled: !0
                    },
                    env: {
                        locale: (e=>{
                            const a = new Proxy(new URLSearchParams(window.location.search),{
                                get: (e,a)=>e.get(a)
                            });
                            if (a.lang)
                                return a.lang;
                            let n = (navigator.language || navigator.userLanguage).substr(0, 2);
                            return -1 === e.indexOf(n) && (n = "en"),
                            n
                        }
                        )(e.supportedLanguages)
                    },
                    user: {
                        avatar: "",
                        avatarBase64: "",
                        name: "Fake User",
                        userId: "1234"
                    }
                }
            };
            var o = window._azerionIntegration;
            window.hasOwnProperty("fbrqSA") && !0 === window.fbrqSA && (h5branding.Utils.ASSET_LOCATION = "assets/"),
            h5branding.SplashLoader.getInstance({
                gameId: o.gdId,
                gameName: document.title,
                gameTitle: document.title,
                libs: [],
                version: "1.0"
            }).create().then((()=>{
                azAdWrapper = new h5ads.AdWrapper(o.advType,o.gdId),
                t(null, d, sgSdk)
            }
            )).catch((e=>{}
            ))
        },
        trigger: function(u, p, w) {
            switch (u) {
            case "restore":
                !function(e, a) {
                    e.callback.call(a, null, localStorage.getItem(e.key))
                }(p, w);
                break;
            case "save":
                !function(e, a) {
                    localStorage.setItem(e.key, e.value),
                    e.callBack && e.callback.call(a)
                }(p, w);
                break;
            case "loading.completed":
                !function(l, u) {
                    azAdWrapper.on(h5ads.AdEvents.CONTENT_PAUSED, (()=>{
                        s(),
                        a = !0
                    }
                    )),
                    azAdWrapper.on(h5ads.AdEvents.CONTENT_RESUMED, (()=>{
                        window.focus(),
                        a = !1,
                        function() {
                            let e = document.getElementById("loader");
                            e && (e.style.display = "none")
                        }(),
                        r()
                    }
                    )),
                    l.callback.call(u),
                    e.runGame && e.runGame(),
                    n = !0,
                    window.game.stage.disableVisibilityChange = !0,
                    window.game.canvas.oncontextmenu = function(e) {
                        e.preventDefault()
                    }
                    ,
                    Phaser.Stage.prototype.visibilityChange = t,
                    window.game.onBlur.add(i),
                    window.game.onFocus.add(c),
                    window.game.onPause.add(d),
                    window.game.onResume.add(o)
                }(p, w);
                break;
            case "loading.update":
                !function(e, a) {
                    h5branding.SplashLoader.getInstance().setLoadProgress(e.progressPercentage)
                }(p);
                break;
            case "levelStart":
            case "gameTracking":
            case "start":
            case "levelFinish":
            default:
                break;
            case "beforePlayButtonDisplay":
            case "playButtonPressed":
                !function(e, a) {
                    e.callback.call(a)
                }(p, w);
                break;
            case "interstitialAd":
                g(p, w);
                break;
            case "rewardedAd":
                !function(e, ctx) {
                    l();
                    s();
                    let n = !1;
                    try {
                        const p = __acp.showAd("rewarded");
                        p.then((()=>{}
                        )).catch((()=>{}
                        )),
                        p.then((()=>{
                            n = !0
                        }
                        )).catch((()=>{
                            n = !1
                        }
                        )),
                        p.then((()=>{
                            a = !1,
                            function() {
                                let e = document.getElementById("loader");
                                e && (e.style.display = "none")
                            }(),
                            r(),
                            e.callback.call(ctx, n)
                        }
                        )).catch((()=>{
                            a = !1,
                            function() {
                                let e = document.getElementById("loader");
                                e && (e.style.display = "none")
                            }(),
                            r(),
                            e.callback.call(ctx, !1)
                        }
                        ));
                        return
                    } catch (t) {}
                    azAdWrapper.once(h5ads.AdEvents.AD_REWARDED, (()=>{
                        n = !0
                    }
                    )),
                    azAdWrapper.once(h5ads.AdEvents.CONTENT_RESUMED, (()=>{
                        azAdWrapper.preloadAd(h5ads.AdType.rewarded),
                        e.callback.call(ctx, n)
                    }
                    )),
                    azAdWrapper.showAd(h5ads.AdType.rewarded)
                }(p, w)
            }
        },
        isAdPlaying: function() {
            return a
        }
    }
}();
